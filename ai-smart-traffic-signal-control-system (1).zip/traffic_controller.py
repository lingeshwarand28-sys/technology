"""
traffic_controller.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Traffic Signal Controller & Decision Engine
===============================================================================

This module handles:
1. Signal state allocation (GREEN, YELLOW, RED) across 4 intersection lanes.
2. AI Dynamic Decision Engine for vehicle density-based signal timing.
3. Instant Emergency Override Signal Lock (Green for emergency lane, Red for all others).
4. Automatic transition & signal resumption back to AI Dynamic Control upon clearance.
"""

from typing import Dict, List, Optional
import time


class SignalState:
    GREEN = "GREEN"
    YELLOW = "YELLOW"
    RED = "RED"


class TrafficSignalController:
    """
    Traffic Signal Controller & AI Decision Engine.
    Allocates signal timing based on YOLOv8 vehicle density counts during normal operations,
    or locks signals in Emergency Override Mode when an emergency vehicle is detected.
    """

    def __init__(self, lanes: List[int] = None):
        self.lanes = lanes or [1, 2, 3, 4]  # 1: North, 2: South, 3: East, 4: West
        self.signal_mode = "AI Dynamic Control"  # 'AI Dynamic Control' or 'Emergency Override'
        
        # Current signal state for each lane
        self.lane_signals: Dict[int, str] = {
            1: SignalState.GREEN,
            2: SignalState.RED,
            3: SignalState.RED,
            4: SignalState.RED
        }

        self.current_green_lane: int = 1
        self.green_timer_remaining: float = 15.0
        self.yellow_timer_remaining: float = 0.0
        self.is_yellow_phase: bool = False
        
        # Timing constants
        self.MIN_GREEN_TIME = 8.0     # Minimum green light duration (seconds)
        self.MAX_GREEN_TIME = 45.0    # Maximum green light duration (seconds)
        self.SEC_PER_VEHICLE = 2.0    # Allocated time per vehicle detected by YOLOv8
        self.YELLOW_TIME = 3.0         # Transition yellow light duration
        
        # Last known vehicle density per lane
        self.lane_densities: Dict[int, int] = {1: 0, 2: 0, 3: 0, 4: 0}

    def set_emergency_override(self, emergency_lane: int):
        """
        Activates Emergency Override Mode:
        - Sets signal_mode = 'Emergency Override'
        - Instantly sets target emergency_lane = GREEN
        - Sets ALL other lanes = RED
        """
        self.signal_mode = "Emergency Override"
        self.current_green_lane = emergency_lane
        self.is_yellow_phase = False
        self.yellow_timer_remaining = 0.0

        for lane in self.lanes:
            if lane == emergency_lane:
                self.lane_signals[lane] = SignalState.GREEN
            else:
                self.lane_signals[lane] = SignalState.RED

        print(f"[TrafficController] Emergency Override Activated! Lane {emergency_lane} set to GREEN. All other lanes locked to RED.")

    def resume_ai_dynamic_control(self, lane_counts: Optional[Dict[int, int]] = None):
        """
        Restores AI Dynamic Control Mode:
        - Sets signal_mode = 'AI Dynamic Control'
        - Recalculates dynamic green time for current green lane or highest-density lane
        - Resumes normal decision engine cycle
        """
        self.signal_mode = "AI Dynamic Control"
        if lane_counts:
            self.lane_densities.update(lane_counts)

        # Select highest density lane or cycle to next lane
        next_lane = self._calculate_highest_density_lane()
        self.current_green_lane = next_lane
        self.green_timer_remaining = self.calculate_dynamic_green_time(self.lane_densities.get(next_lane, 0))
        self.is_yellow_phase = False

        for lane in self.lanes:
            if lane == next_lane:
                self.lane_signals[lane] = SignalState.GREEN
            else:
                self.lane_signals[lane] = SignalState.RED

        print(f"[TrafficController] AI Dynamic Control Resumed. Active Green Lane: Lane {next_lane} ({self.green_timer_remaining:.1f}s)")

    def calculate_dynamic_green_time(self, vehicle_count: int) -> float:
        """
        Decision Engine: Dynamically calculates green signal duration based on lane vehicle density.
        Formula: Green Duration = max(MIN_GREEN, min(MAX_GREEN, MIN_GREEN + (Count * SEC_PER_VEHICLE)))
        """
        allocated_time = self.MIN_GREEN_TIME + (vehicle_count * self.SEC_PER_VEHICLE)
        return max(self.MIN_GREEN_TIME, min(self.MAX_GREEN_TIME, allocated_time))

    def update_cycle(self, dt: float, lane_counts: Dict[int, int]):
        """
        Advances the traffic signal clock by `dt` seconds.
        In 'AI Dynamic Control' mode, manages countdown timers and rotates green signal.
        In 'Emergency Override' mode, locks emergency lane to GREEN and ignores normal rotation.
        """
        self.lane_densities.update(lane_counts)

        if self.signal_mode == "Emergency Override":
            # Emergency Mode: keep emergency lane GREEN and freeze AI timer rotation
            return

        # AI Dynamic Control Mode
        if self.is_yellow_phase:
            self.yellow_timer_remaining -= dt
            if self.yellow_timer_remaining <= 0:
                self.is_yellow_phase = False
                # Rotate to next green lane based on density or round-robin
                self.current_green_lane = self._calculate_highest_density_lane()
                self.green_timer_remaining = self.calculate_dynamic_green_time(
                    self.lane_densities.get(self.current_green_lane, 0)
                )
                
                for lane in self.lanes:
                    if lane == self.current_green_lane:
                        self.lane_signals[lane] = SignalState.GREEN
                    else:
                        self.lane_signals[lane] = SignalState.RED
        else:
            self.green_timer_remaining -= dt
            if self.green_timer_remaining <= 0:
                # Transition current green lane to yellow
                self.is_yellow_phase = True
                self.yellow_timer_remaining = self.YELLOW_TIME
                self.lane_signals[self.current_green_lane] = SignalState.YELLOW

    def _calculate_highest_density_lane(self) -> int:
        """
        Selects lane with highest vehicle count.
        If all equal or zero, rotates sequentially to next lane.
        """
        max_count = -1
        selected_lane = self.current_green_lane

        # Check candidate lanes other than current green lane first
        candidates = [l for l in self.lanes if l != self.current_green_lane]
        for lane in candidates:
            count = self.lane_densities.get(lane, 0)
            if count > max_count and count > 0:
                max_count = count
                selected_lane = lane

        # Fallback to sequential round-robin
        if max_count <= 0:
            current_idx = self.lanes.index(self.current_green_lane)
            selected_lane = self.lanes[(current_idx + 1) % len(self.lanes)]

        return selected_lane

    def get_signal_status(self) -> Dict[str, any]:
        """Returns signal controller state summary for UI/Dashboard."""
        return {
            "signal_mode": self.signal_mode,
            "current_green_lane": self.current_green_lane,
            "lane_signals": self.lane_signals,
            "timer_remaining": round(self.yellow_timer_remaining if self.is_yellow_phase else self.green_timer_remaining, 1),
            "is_yellow": self.is_yellow_phase,
            "lane_densities": self.lane_densities
        }
