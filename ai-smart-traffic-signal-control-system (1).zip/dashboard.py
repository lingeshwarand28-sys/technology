"""
dashboard.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Dashboard View & Status Controller
===============================================================================

This module handles:
1. Formatting and rendering current dashboard system metrics.
2. Rendering required status fields:
   - Emergency Status: ACTIVE / INACTIVE
   - AI Detection: ACTIVE / PAUSED
   - Signal Mode: AI Dynamic Control / Emergency Override
3. Displaying active notification toasts (e.g. "✅ Emergency Cleared – AI Traffic Control Resumed").
4. Visualizing active emergency tracking coordinates and queued emergency vehicles.
"""

from typing import Dict, List, Optional
import time


class TrafficDashboard:
    """
    Dashboard Controller for AI Smart Traffic Signal System.
    Provides structured status data and formatted UI output.
    """

    def __init__(self):
        self.banner_notification: Optional[str] = None
        self.notification_history: List[str] = []

    def set_clearance_notification(self):
        """Sets required banner notification: '✅ Emergency Cleared – AI Traffic Control Resumed'"""
        msg = "✅ Emergency Cleared – AI Traffic Control Resumed"
        self.banner_notification = msg
        self.notification_history.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
        return msg

    def clear_banner(self):
        self.banner_notification = None

    def generate_dashboard_view(self, sim_data: Dict[str, any]) -> Dict[str, any]:
        """
        Generates full formatted snapshot for the UI Dashboard.
        Guarantees exact status fields required by specs.
        """
        signals = sim_data.get("signals", {})
        emergency = sim_data.get("emergency_dashboard", {})
        detector = sim_data.get("detector_status", {})
        lane_counts = sim_data.get("lane_counts", {1: 0, 2: 0, 3: 0, 4: 0})

        is_override = emergency.get("emergency_status") == "ACTIVE"

        dashboard_status = {
            "emergency_status": "ACTIVE" if is_override else "INACTIVE",
            "ai_detection": "PAUSED" if is_override else "ACTIVE",
            "signal_mode": "Emergency Override" if is_override else "AI Dynamic Control",
            "banner_notification": self.banner_notification,
            "lane_summary": {
                "Lane 1 (North)": {"count": lane_counts.get(1, 0), "signal": signals.get("lane_signals", {}).get(1, "RED")},
                "Lane 2 (South)": {"count": lane_counts.get(2, 0), "signal": signals.get("lane_signals", {}).get(2, "RED")},
                "Lane 3 (East)": {"count": lane_counts.get(3, 0), "signal": signals.get("lane_signals", {}).get(3, "RED")},
                "Lane 4 (West)": {"count": lane_counts.get(4, 0), "signal": signals.get("lane_signals", {}).get(4, "RED")},
            },
            "active_green_lane": signals.get("current_green_lane"),
            "green_timer_remaining": signals.get("timer_remaining"),
            "active_emergency": emergency.get("active_emergency_vehicle"),
            "queue_length": emergency.get("queued_count", 0),
            "queued_vehicles": emergency.get("queue_summary", []),
            "recent_logs": self.notification_history[-5:]
        }

        return dashboard_status

    def render_cli_dashboard(self, status: Dict[str, any]):
        """Renders text-based terminal dashboard view for logging."""
        print("\n" + "="*70)
        print(" 🚦 AI SMART TRAFFIC SIGNAL CONTROL SYSTEM - DASHBOARD ")
        print("="*70)
        
        if status.get("banner_notification"):
            print(f"\n📢 NOTIFICATION: {status['banner_notification']}\n")

        print(f" ► Emergency Status : {status['emergency_status']}")
        print(f" ► AI Detection     : {status['ai_detection']}")
        print(f" ► Signal Mode      : {status['signal_mode']}")
        print(f" ► Current Green    : Lane {status['active_green_lane']} ({status['green_timer_remaining']}s remaining)")
        print("-" * 70)
        
        print(" LANES & VEHICLE DENSITY:")
        for lane_name, info in status["lane_summary"].items():
            sig_icon = "🟢" if info["signal"] == "GREEN" else ("🟡" if info["signal"] == "YELLOW" else "🔴")
            print(f"   • {lane_name:18s}: {sig_icon} {info['signal']:6s} | Density: {info['count']} vehicles")

        print("-" * 70)
        if status.get("active_emergency"):
            ev = status["active_emergency"]
            print(f" 🚨 ACTIVE EMERGENCY: {ev['type']} ({ev['id']}) in Lane {ev['lane']} | Status: {ev['status']}")
        else:
            print(" 🚨 ACTIVE EMERGENCY: None")

        print(f" ⏳ QUEUED EMERGENCIES: {status['queue_length']} waiting ({', '.join(status['queued_vehicles']) or 'None'})")
        print("="*70 + "\n")
