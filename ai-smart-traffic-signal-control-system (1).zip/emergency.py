"""
emergency.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Emergency Vehicle Management Module
===============================================================================

This module handles:
1. Detection and registration of emergency vehicles (Ambulance, Fire Truck, Police).
2. Emergency Override Mode activation and lane signal locking.
3. Continuous tracking of emergency vehicle bounding boxes and positions.
4. Automatic intersection clearance detection using spatial bounding box coordinates.
5. Automatic reset of emergency override, flag resetting, queue processing, and system restoration.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict
import time


@dataclass
class EmergencyVehicle:
    """Dataclass representing an emergency vehicle inside the detection workspace."""
    vehicle_id: str
    vehicle_type: str  # 'Ambulance', 'Fire Truck', or 'Police Vehicle'
    lane_id: int       # 1: North, 2: South, 3: East, 4: West
    bbox: Tuple[float, float, float, float]  # [x1, y1, x2, y2]
    confidence: float
    position: Tuple[float, float]  # (x, y) center position
    speed: float = 30.0  # speed in km/h or pixels/sec
    status: str = "approaching"  # 'approaching', 'crossing', 'cleared'
    timestamp: float = field(default_factory=time.time)

    @property
    def center_x(self) -> float:
        return (self.bbox[0] + self.bbox[2]) / 2.0

    @property
    def center_y(self) -> float:
        return (self.bbox[1] + self.bbox[3]) / 2.0


class EmergencyManager:
    """
    Automatic Emergency Vehicle Management Engine.
    Handles queueing, active override, continuous tracking, bounding box clearance,
    and automatic transition back to AI Dynamic Control.
    """

    def __init__(self, intersection_bounds: Optional[Dict[str, float]] = None):
        # Intersection bounding coordinates [x_min, x_max, y_min, y_max]
        self.intersection_bounds = intersection_bounds or {
            "x_min": 200.0,
            "x_max": 600.0,
            "y_min": 200.0,
            "y_max": 600.0
        }

        # Lane clearance boundaries (Exit coordinates for each lane)
        # Lane 1 (North -> moving South): Exits when y > y_max
        # Lane 2 (South -> moving North): Exits when y < y_min
        # Lane 3 (East -> moving West): Exits when x < x_min
        # Lane 4 (West -> moving East): Exits when x > x_max
        
        self.active_emergency: Optional[EmergencyVehicle] = None
        self.emergency_queue: List[EmergencyVehicle] = []
        self.override_active: bool = False
        self.active_lane: Optional[int] = None
        
        # System Notification Log
        self.notifications: List[Dict[str, str]] = []
        self.cleared_history: List[EmergencyVehicle] = []

    def register_emergency_vehicle(self, vehicle: EmergencyVehicle) -> Dict[str, str]:
        """
        Registers a detected emergency vehicle.
        If no emergency is active, immediately activates Emergency Override Mode.
        If an emergency is already active, queues the vehicle for subsequent processing.
        """
        if not self.override_active and self.active_emergency is None:
            # Activate Emergency Override immediately
            self.active_emergency = vehicle
            self.override_active = True
            self.active_lane = vehicle.lane_id
            vehicle.status = "crossing"
            
            msg = f"🚨 EMERGENCY OVERRIDE ACTIVATED: {vehicle.vehicle_type} ({vehicle.vehicle_id}) detected in Lane {vehicle.lane_id}!"
            self._add_notification(msg, category="EMERGENCY_START")
            return {
                "action": "OVERRIDE_ACTIVATED",
                "message": msg,
                "lane_id": vehicle.lane_id,
                "vehicle": vehicle.vehicle_type
            }
        else:
            # Check if vehicle is already in queue or active to prevent duplicates
            is_active = self.active_emergency and self.active_emergency.vehicle_id == vehicle.vehicle_id
            is_queued = any(v.vehicle_id == vehicle.vehicle_id for v in self.emergency_queue)
            
            if not is_active and not is_queued:
                self.emergency_queue.append(vehicle)
                msg = f"⏳ Emergency Vehicle Queued: {vehicle.vehicle_type} ({vehicle.vehicle_id}) queued for Lane {vehicle.lane_id}. Queue position: {len(self.emergency_queue)}"
                self._add_notification(msg, category="QUEUE_ADDED")
                return {
                    "action": "QUEUED",
                    "message": msg,
                    "queue_position": len(self.emergency_queue)
                }
            
            return {"action": "DUPLICATE_IGNORED", "message": "Vehicle already tracked."}

    def update_vehicle_position(self, vehicle_id: str, new_bbox: Tuple[float, float, float, float], current_lane: int) -> Dict[str, any]:
        """
        Continuously updates position & bounding box of active emergency vehicle.
        Evaluates if the vehicle has completely passed through the intersection.
        """
        if not self.active_emergency or self.active_emergency.vehicle_id != vehicle_id:
            return {"status": "NO_MATCHING_ACTIVE_EMERGENCY"}

        # Update position
        self.active_emergency.bbox = new_bbox
        self.active_emergency.lane_id = current_lane
        self.active_emergency.position = (self.active_emergency.center_x, self.active_emergency.center_y)

        # Check if vehicle has completely exited the intersection
        has_cleared = self._check_intersection_clearance(self.active_emergency)

        if has_cleared:
            return self.process_emergency_clearance()

        return {
            "status": "TRACKING",
            "lane_id": self.active_emergency.lane_id,
            "center": self.active_emergency.position,
            "vehicle_status": self.active_emergency.status
        }

    def _check_intersection_clearance(self, vehicle: EmergencyVehicle) -> bool:
        """
        Determines if an emergency vehicle's bounding box has completely crossed
        and exited the intersection polygon based on its travel direction (lane).
        """
        x1, y1, x2, y2 = vehicle.bbox
        cx, cy = vehicle.center_x, vehicle.center_y
        bounds = self.intersection_bounds

        # Lane 1 (North -> South): Exit when top bound y1 > y_max
        if vehicle.lane_id == 1:
            return y1 > bounds["y_max"]

        # Lane 2 (South -> North): Exit when bottom bound y2 < y_min
        elif vehicle.lane_id == 2:
            return y2 < bounds["y_min"]

        # Lane 3 (East -> West): Exit when right bound x2 < x_min
        elif vehicle.lane_id == 3:
            return x2 < bounds["x_min"]

        # Lane 4 (West -> East): Exit when left bound x1 > x_max
        elif vehicle.lane_id == 4:
            return x1 > bounds["x_max"]

        # Default fallback: check if center point is completely outside bounds
        is_outside = (cx < bounds["x_min"] or cx > bounds["x_max"] or
                      cy < bounds["y_min"] or cy > bounds["y_max"])
        return is_outside

    def process_emergency_clearance(self) -> Dict[str, any]:
        """
        Executes automatic clearance workflow:
        1. Resets emergency flags.
        2. Removes cleared vehicle from active emergency list.
        3. Posts notification "✅ Emergency Cleared – AI Traffic Control Resumed".
        4. Checks emergency queue for waiting emergency vehicles.
        5. If queue is non-empty, immediately processes next emergency.
        6. Otherwise, safely transitions system back to AI Dynamic Control mode.
        """
        cleared_ev = self.active_emergency
        if cleared_ev:
            cleared_ev.status = "cleared"
            self.cleared_history.append(cleared_ev)

        # Reset active flags
        self.active_emergency = None
        self.override_active = False
        self.active_lane = None

        cleared_msg = "✅ Emergency Cleared – AI Traffic Control Resumed"
        self._add_notification(cleared_msg, category="CLEARANCE")

        # Check if another emergency vehicle is waiting in queue (Requirement #9)
        if len(self.emergency_queue) > 0:
            next_ev = self.emergency_queue.pop(0)
            queue_msg = f"🔄 Processing Queued Emergency Vehicle: {next_ev.vehicle_type} ({next_ev.vehicle_id}) in Lane {next_ev.lane_id}"
            self._add_notification(queue_msg, category="QUEUE_DISPATCH")
            
            # Activate next emergency vehicle automatically
            self.active_emergency = next_ev
            self.override_active = True
            self.active_lane = next_ev.lane_id
            next_ev.status = "crossing"
            
            return {
                "status": "NEXT_EMERGENCY_ACTIVATED",
                "cleared_vehicle": cleared_ev.vehicle_id if cleared_ev else None,
                "next_vehicle": next_ev,
                "lane_id": next_ev.lane_id,
                "message": f"{cleared_msg} | {queue_msg}"
            }

        return {
            "status": "ALL_EMERGENCIES_CLEARED",
            "cleared_vehicle": cleared_ev.vehicle_id if cleared_ev else None,
            "message": cleared_msg,
            "dashboard_updates": {
                "emergency_status": "INACTIVE",
                "ai_detection": "ACTIVE",
                "signal_mode": "AI Dynamic Control"
            }
        }

    def _add_notification(self, text: str, category: str = "INFO"):
        self.notifications.append({
            "timestamp": time.strftime("%H:%M:%S"),
            "category": category,
            "message": text
        })

    def get_dashboard_state((self) -> Dict[str, any]:
        """Returns emergency management metrics for dashboard display."""
        return {
            "emergency_status": "ACTIVE" if self.override_active else "INACTIVE",
            "ai_detection": "PAUSED (Override)" if self.override_active else "ACTIVE",
            "signal_mode": "Emergency Override" if self.override_active else "AI Dynamic Control",
            "active_emergency_vehicle": {
                "id": self.active_emergency.vehicle_id,
                "type": self.active_emergency.vehicle_type,
                "lane": self.active_emergency.lane_id,
                "status": self.active_emergency.status
            } if self.active_emergency else None,
            "queued_count": len(self.emergency_queue),
            "queue_summary": [f"{v.vehicle_type} (Lane {v.lane_id})" for v in self.emergency_queue],
            "recent_notification": self.notifications[-1]["message"] if self.notifications else None
        }
