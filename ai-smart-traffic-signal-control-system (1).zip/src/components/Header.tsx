import React from 'react';
import { Activity, AlertTriangle, ShieldCheck, Cpu, Code2, Play, Pause, RefreshCw, Radio } from 'lucide-react';

interface HeaderProps {
  emergencyStatus: 'ACTIVE' | 'INACTIVE';
  aiDetection: 'ACTIVE' | 'PAUSED';
  signalMode: 'AI Dynamic Control' | 'Emergency Override';
  activeTab: 'sim' | 'code' | 'logs';
  setActiveTab: (tab: 'sim' | 'code' | 'logs') => void;
  isPaused: boolean;
  togglePause: () => void;
  resetSim: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  emergencyStatus,
  aiDetection,
  signalMode,
  activeTab,
  setActiveTab,
  isPaused,
  togglePause,
  resetSim
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand & Title */}
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-indigo-600/20 border border-indigo-500/30 rounded-xl text-indigo-400">
              <Radio className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                  AI Smart Traffic Signal Control System
                </h1>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  v2.0 Automatic Override
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                YOLOv8 Lane Density Engine & Automated Emergency Clearance Tracker
              </p>
            </div>
          </div>

          {/* Real-time Status Badges */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Emergency Status */}
            <div className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border font-medium transition-all ${
              emergencyStatus === 'ACTIVE'
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 animate-pulse'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}>
              <AlertTriangle className={`w-3.5 h-3.5 ${emergencyStatus === 'ACTIVE' ? 'text-rose-400 animate-bounce' : 'text-emerald-400'}`} />
              <span className="text-slate-400">Emergency Status:</span>
              <span className="font-bold tracking-wide">{emergencyStatus}</span>
            </div>

            {/* AI Detection */}
            <div className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border font-medium ${
              aiDetection === 'ACTIVE'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
            }`}>
              <Cpu className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400">AI Detection:</span>
              <span className="font-bold">{aiDetection}</span>
            </div>

            {/* Signal Mode */}
            <div className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border font-medium ${
              signalMode === 'Emergency Override'
                ? 'bg-rose-500/15 border-rose-500/40 text-rose-300'
                : 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300'
            }`}>
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-slate-400">Signal Mode:</span>
              <span className="font-bold">{signalMode}</span>
            </div>
          </div>

        </div>

        {/* Tab Navigation & Simulation Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800">
          
          {/* Tabs */}
          <div className="flex items-center space-x-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800/80 w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('sim')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'sim'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Interactive Simulation</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Python Code & Architecture</span>
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'logs'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>System Event Logs</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
            <button
              onClick={togglePause}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            >
              {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-400" /> : <Pause className="w-3.5 h-3.5 text-amber-400" />}
              <span>{isPaused ? 'Resume Clock' : 'Pause Clock'}</span>
            </button>

            <button
              onClick={resetSim}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
              <span>Reset State</span>
            </button>
          </div>

        </div>

      </div>
    </header>
  );
};
