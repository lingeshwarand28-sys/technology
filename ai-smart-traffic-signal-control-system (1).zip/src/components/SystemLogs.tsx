import React from 'react';
import { LogEntry } from '../types';
import { Terminal, ShieldAlert, CheckCircle2, Layers, Cpu } from 'lucide-react';

interface SystemLogsProps {
  logs: LogEntry[];
  onClearLogs: () => void;
}

export const SystemLogs: React.FC<SystemLogsProps> = ({ logs, onClearLogs }) => {
  const getLogIcon = (category: string) => {
    switch (category) {
      case 'CLEARANCE': return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'OVERRIDE': return <ShieldAlert className="w-4 h-4 text-rose-400" />;
      case 'QUEUE': return <Layers className="w-4 h-4 text-indigo-400" />;
      case 'DENSITY': return <Cpu className="w-4 h-4 text-amber-400" />;
      default: return <Terminal className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
        <div className="flex items-center space-x-2">
          <Terminal className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-slate-200">System Event Log & State Audit Trail</h3>
        </div>
        <button
          onClick={onClearLogs}
          className="text-xs text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          Clear Audit Trail
        </button>
      </div>

      <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1 custom-scrollbar">
        {logs.length > 0 ? (
          logs.map((log) => (
            <div
              key={log.id}
              className={`p-3 rounded-xl border font-mono text-xs flex items-start space-x-3 ${
                log.category === 'CLEARANCE'
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                  : log.category === 'OVERRIDE'
                  ? 'bg-rose-950/30 border-rose-500/40 text-rose-200'
                  : 'bg-slate-950 border-slate-800/80 text-slate-300'
              }`}
            >
              <div className="mt-0.5 shrink-0">{getLogIcon(log.category)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                  <span className="font-semibold text-slate-400">[{log.category}]</span>
                  <span>{log.timestamp}</span>
                </div>
                <p className="whitespace-pre-wrap break-words">{log.message}</p>
              </div>
            </div>
          ))
        ) : (
          <div className="py-12 text-center text-xs text-slate-500">
            No events recorded yet. Perform actions or dispatch emergency vehicles to trigger audit logs.
          </div>
        )}
      </div>
    </div>
  );
};
