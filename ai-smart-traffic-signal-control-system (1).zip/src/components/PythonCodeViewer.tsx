import React, { useState } from 'react';
import { pythonCodeFiles } from '../data/pythonCode';
import { FileCode, Copy, Check, Download, Info, CheckCircle2 } from 'lucide-react';

export const PythonCodeViewer: React.FC = () => {
  const [selectedFilename, setSelectedFilename] = useState<string>('emergency.py');
  const [copied, setCopied] = useState<boolean>(false);

  const activeFile = pythonCodeFiles.find((f) => f.filename === selectedFilename) || pythonCodeFiles[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (filename: string, code: string) => {
    const blob = new Blob([code], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadAll = () => {
    pythonCodeFiles.forEach((file) => {
      handleDownload(file.filename, file.code);
    });
  };

  return (
    <div className="space-y-4">
      
      {/* Explanation Banner */}
      <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-indigo-200">
        <div className="flex items-start space-x-3">
          <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white">
              Complete Production Python Source Code Modules
            </h3>
            <p className="text-xs text-indigo-300/80 leading-relaxed">
              Below are the complete, updated Python source code files implementing the fully automatic Emergency Vehicle Management System with bounding box clearance tracking, emergency queueing, status restoration, and YOLOv8 vehicle detection integration.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        
        {/* File Selector Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <div className="flex items-center justify-between px-2 pb-2 text-xs text-slate-400 font-semibold border-b border-slate-800">
            <span>Module Files ({pythonCodeFiles.length})</span>
            <button
              onClick={handleDownloadAll}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
            >
              <Download className="w-3 h-3" />
              <span>Download All</span>
            </button>
          </div>

          <div className="space-y-1.5">
            {pythonCodeFiles.map((f) => (
              <button
                key={f.filename}
                onClick={() => setSelectedFilename(f.filename)}
                className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between ${
                  selectedFilename === f.filename
                    ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <FileCode className={`w-4 h-4 shrink-0 ${selectedFilename === f.filename ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-mono truncate">{f.filename}</span>
                </div>
                <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${selectedFilename === f.filename ? 'text-indigo-400' : 'opacity-0'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Code View Canvas */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden flex flex-col shadow-2xl">
          
          {/* Header toolbar */}
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-sm font-bold text-white font-mono">{activeFile.filename}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono">Python 3.10+</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{activeFile.description}</p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition-colors border border-slate-700"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>

              <button
                onClick={() => handleDownload(activeFile.filename, activeFile.code)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .py</span>
              </button>
            </div>
          </div>

          {/* Code text block with line numbers */}
          <div className="p-4 overflow-x-auto max-h-[580px] custom-scrollbar font-mono text-xs text-slate-300 leading-relaxed bg-slate-950">
            <pre>
              {activeFile.code.split('\n').map((line, idx) => (
                <div key={idx} className="table-row hover:bg-slate-900/60 px-2 rounded">
                  <span className="table-cell select-none pr-4 text-right text-slate-600 text-[11px] w-10">
                    {idx + 1}
                  </span>
                  <span className="table-cell whitespace-pre">{line}</span>
                </div>
              ))}
            </pre>
          </div>

        </div>

      </div>

      {/* Modifications Summary Cards */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="text-sm font-bold text-slate-200">Key Modifications & Implementation Breakdown</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">1. Automatic Override Activation</span>
            <p className="text-slate-400">
              When an Ambulance, Fire Truck, or Police Vehicle is detected by YOLOv8, Emergency Override Mode is immediately engaged, locking green light on emergency lane and locking all other lanes red.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">2. Bounding Box Exit Clearance</span>
            <p className="text-slate-400">
              `_check_intersection_clearance()` calculates whether the emergency vehicle bounding box coordinates `[x1, y1, x2, y2]` have passed the lane exit line of the intersection polygon.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">3. Automated Queue Processing</span>
            <p className="text-slate-400">
              If multiple emergency vehicles arrive, subsequent ones are queued in `emergency_queue`. Upon clearance, the system automatically pops the next waiting emergency vehicle.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">4. Notification & Status Reset</span>
            <p className="text-slate-400">
              Upon final clearance, automatically posts "✅ Emergency Cleared – AI Traffic Control Resumed", sets status to INACTIVE, resets emergency flags, and restarts YOLOv8 vehicle counting.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">5. AI Dynamic Signal Allocation</span>
            <p className="text-slate-400">
              The Decision Engine dynamically calculates green light duration based on YOLOv8 vehicle counts per lane: `Green = max(8s, min(45s, 8s + (Count * 2s)))`.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="font-bold text-indigo-400 block mb-1">6. Zero User Interaction</span>
            <p className="text-slate-400">
              Transitions from Emergency Override back to AI Dynamic Control are 100% automated via continuous position tracking and boundary trigger hooks.
            </p>
          </div>

        </div>
      </div>

    </div>
  );
};
