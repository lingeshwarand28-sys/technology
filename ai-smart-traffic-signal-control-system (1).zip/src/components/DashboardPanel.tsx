import React from 'react';
import { EmergencyDashboardState, SignalStatus, LaneId } from '../types';
import { AlertTriangle, Cpu, ShieldCheck, Siren, Layers, Car, Flame, ShieldAlert, Zap } from 'lucide-react';

interface DashboardPanelProps {
  emergencyState: EmergencyDashboardState;
  signals: SignalStatus;
  laneCounts: Record<LaneId, number>;
  onDispatchEmergency: (type: 'Ambulance' | 'Fire Truck' | 'Police Vehicle', lane: LaneId) => void;
  onDispatchQueueDemo: () => void;
  onAddTraffic: () => void;
}

export const DashboardPanel: React.FC<DashboardPanelProps> = ({
  emergencyState,
  signals,
  laneCounts,
  onDispatchEmergency,
  onDispatchQueueDemo,
  onAddTraffic
}) => {
  const laneNames: Record<LaneId, string> = {
    1: 'Lane 1 (North)',
    2: 'Lane 2 (South)',
    3: 'Lane 3 (East)',
    4: 'Lane 4 (West)',
  };

  return (
    <div className="space-y-4">
      
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        
        {/* Metric 1: Emergency Status */}
        <div className={`p-4 rounded-2xl border transition-all ${
          emergencyState.emergencyStatus === 'ACTIVE'
            ? 'bg-rose-950/40 border-rose-500/50 shadow-lg shadow-rose-950/30'
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Emergency Status</span>
            <AlertTriangle className={`w-4 h-4 ${emergencyState.emergencyStatus === 'ACTIVE' ? 'text-rose-400 animate-pulse' : 'text-slate-500'}`} />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className={`text-xl font-extrabold ${
              emergencyState.emergencyStatus === 'ACTIVE' ? 'text-rose-400' : 'text-emerald-400'
            }`}>
              {emergencyState.emergencyStatus}
            </span>
            <span className="text-xs text-slate-400">
              {emergencyState.emergencyStatus === 'ACTIVE' ? 'Override Mode Engaged' : 'No Active Overrides'}
            </span>
          </div>
        </div>

        {/* Metric 2: AI Detection */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>AI Detection Engine</span>
            <Cpu className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className={`text-xl font-extrabold ${
              emergencyState.aiDetection === 'ACTIVE' ? 'text-emerald-400' : 'text-amber-400'
            }`}>
              {emergencyState.aiDetection}
            </span>
            <span className="text-xs text-slate-400">YOLOv8 Real-time Feed</span>
          </div>
        </div>

        {/* Metric 3: Signal Mode */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Signal Control Mode</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline space-x-2">
            <span className={`text-lg font-bold ${
              signals.signalMode === 'Emergency Override' ? 'text-rose-400' : 'text-indigo-400'
            }`}>
              {signals.signalMode}
            </span>
          </div>
        </div>

      </div>

      {/* Emergency Dispatcher Quick Controls */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Siren className="w-4 h-4 text-rose-400" />
            <h3 className="text-sm font-bold text-slate-200">Emergency Dispatch & Queue Testing Controls</h3>
          </div>
          <span className="text-xs text-slate-500">Triggers Override / Auto Clearance</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          
          <button
            onClick={() => onDispatchEmergency('Ambulance', 1)}
            className="flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-200 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
          >
            <span>🚑 Dispatch Ambulance (L1)</span>
          </button>

          <button
            onClick={() => onDispatchEmergency('Fire Truck', 3)}
            className="flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl bg-orange-600/20 hover:bg-orange-600/30 border border-orange-500/40 text-orange-200 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
          >
            <span>🚒 Dispatch Fire Truck (L3)</span>
          </button>

          <button
            onClick={() => onDispatchEmergency('Police Vehicle', 2)}
            className="flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-200 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
          >
            <span>🚓 Dispatch Police (L2)</span>
          </button>

          <button
            onClick={onDispatchQueueDemo}
            className="flex items-center justify-center space-x-2 px-3 py-2.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-200 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
            title="Spawns 2 emergency vehicles simultaneously to demonstrate requirements #9 (queueing)"
          >
            <Zap className="w-3.5 h-3.5 text-indigo-400" />
            <span>Test Queueing (L1 + L3)</span>
          </button>

        </div>

        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="text-slate-400">Simulate normal vehicle density:</span>
          <button
            onClick={onAddTraffic}
            className="flex items-center space-x-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
          >
            <Car className="w-3.5 h-3.5 text-indigo-400" />
            <span>+ Add 5 Traffic Cars</span>
          </button>
        </div>
      </div>

      {/* Active Emergency Tracking & Queue Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Active Emergency Box */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
            <span className="text-xs font-bold text-slate-300 flex items-center space-x-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Active Emergency Vehicle Tracker</span>
            </span>
            <span className="text-[11px] text-slate-500 font-mono">BBox Coordinates</span>
          </div>

          {emergencyState.activeEmergency ? (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between bg-rose-950/40 border border-rose-500/30 rounded-xl p-3">
                <div>
                  <div className="text-sm font-bold text-white flex items-center space-x-2">
                    <span>{emergencyState.activeEmergency.type}</span>
                    <span className="text-xs font-mono text-rose-300">({emergencyState.activeEmergency.id})</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Assigned Lane: <span className="text-white font-semibold">Lane {emergencyState.activeEmergency.lane}</span>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-bold animate-pulse border border-rose-500/30">
                  {emergencyState.activeEmergency.status.toUpperCase()}
                </span>
              </div>

              <div className="bg-slate-950 rounded-xl p-3 font-mono text-xs text-slate-400 border border-slate-800 space-y-1">
                <div className="flex justify-between">
                  <span>Bounding Box [x1,y1,x2,y2]:</span>
                  <span className="text-cyan-400">
                    [{emergencyState.activeEmergency.bbox.map(b => Math.round(b)).join(', ')}]
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Center Coordinates (X, Y):</span>
                  <span className="text-emerald-400">
                    ({Math.round(emergencyState.activeEmergency.position.x)}, {Math.round(emergencyState.activeEmergency.position.y)})
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-500">
              No emergency vehicle currently in intersection.
            </div>
          )}
        </div>

        {/* Emergency Queue Box (Requirement #9) */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
            <span className="text-xs font-bold text-slate-300 flex items-center space-x-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              <span>Emergency Waiting Queue</span>
            </span>
            <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
              {emergencyState.queue.length} Waiting
            </span>
          </div>

          {emergencyState.queue.length > 0 ? (
            <div className="space-y-2">
              {emergencyState.queue.map((ev, index) => (
                <div key={ev.id} className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs">
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-[10px]">
                      #{index + 1}
                    </span>
                    <span className="font-semibold text-slate-200">{ev.type}</span>
                    <span className="text-slate-500 font-mono">({ev.id})</span>
                  </div>
                  <span className="text-slate-400">
                    Lane <span className="text-white font-bold">{ev.lane}</span>
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-slate-500">
              Queue is empty. Next detected emergency vehicle will be processed immediately.
            </div>
          )}
        </div>

      </div>

      {/* Lane Density & AI Decision Engine Signal Allocator */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
          <div className="flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-slate-200">Lane Vehicle Density & AI Signal Timing Allocation</h3>
          </div>
          <span className="text-[11px] text-slate-500">Formula: Base 8s + (Density × 2s)</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {([1, 2, 3, 4] as LaneId[]).map((lane) => {
            const count = laneCounts[lane] || 0;
            const signal = signals.laneSignals[lane] || 'RED';
            const isGreen = signal === 'GREEN';
            const isYellow = signal === 'YELLOW';
            const isCurrentGreenLane = signals.currentGreenLane === lane;

            // Calculated green duration
            const allocTime = Math.max(8, Math.min(45, 8 + count * 2));

            return (
              <div
                key={lane}
                className={`p-3 rounded-xl border transition-all ${
                  isGreen
                    ? 'bg-emerald-950/20 border-emerald-500/40 shadow-sm'
                    : isYellow
                    ? 'bg-amber-950/20 border-amber-500/40'
                    : 'bg-slate-950 border-slate-800/80'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-300">{laneNames[lane]}</span>
                  <span className={`w-2.5 h-2.5 rounded-full ${
                    isGreen ? 'bg-emerald-400 animate-pulse' : isYellow ? 'bg-amber-400' : 'bg-rose-500/60'
                  }`} />
                </div>

                <div className="flex items-baseline justify-between mt-2">
                  <div>
                    <span className="text-xl font-extrabold text-white">{count}</span>
                    <span className="text-[10px] text-slate-500 ml-1">vehicles</span>
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                    isGreen
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {signal}
                  </span>
                </div>

                <div className="mt-2 text-[10px] text-slate-500 flex justify-between pt-1.5 border-t border-slate-800/60">
                  <span>AI Allocated Time:</span>
                  <span className="font-mono text-slate-300 font-semibold">{allocTime}s</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
