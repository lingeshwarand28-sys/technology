import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, X } from 'lucide-react';

interface ClearanceBannerProps {
  message: string | null;
  onDismiss: () => void;
}

export const ClearanceBanner: React.FC<ClearanceBannerProps> = ({ message, onDismiss }) => {
  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="mb-4 bg-emerald-950/90 border-2 border-emerald-500 text-emerald-100 rounded-2xl p-4 shadow-2xl shadow-emerald-900/30 backdrop-blur-md relative overflow-hidden"
        >
          {/* Subtle glowing accent background */}
          <div className="absolute -right-12 -top-12 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center space-x-3.5">
              <div className="p-2 bg-emerald-500/20 border border-emerald-400/40 rounded-xl text-emerald-300 shrink-0">
                <CheckCircle2 className="w-6 h-6 animate-bounce" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  {message}
                </h3>
                <p className="text-xs text-emerald-300/80 mt-0.5">
                  Emergency override flags cleared • Queue processed • YOLOv8 vehicle detection & lane counting restarted
                </p>
              </div>
            </div>

            <button
              onClick={onDismiss}
              className="p-1.5 rounded-lg text-emerald-300 hover:text-white hover:bg-emerald-900/50 transition-colors"
              title="Dismiss notification"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
