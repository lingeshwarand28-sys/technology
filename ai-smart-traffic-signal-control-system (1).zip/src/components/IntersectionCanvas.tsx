import React from 'react';
import { Vehicle, SignalStatus, LaneId, SignalColor } from '../types';
import { ShieldAlert, AlertCircle } from 'lucide-react';

interface IntersectionCanvasProps {
  vehicles: Vehicle[];
  signals: SignalStatus;
  activeEmergencyId: string | null;
  activeLane: LaneId | null;
}

export const IntersectionCanvas: React.FC<IntersectionCanvasProps> = ({
  vehicles,
  signals,
  activeEmergencyId,
  activeLane
}) => {
  // Intersection center box coordinates: [200, 200] to [400, 400] on a 600x600 SVG canvas
  const isOverride = signals.signalMode === 'Emergency Override';

  const getSignalColor = (lane: LaneId): SignalColor => {
    return signals.laneSignals[lane] || 'RED';
  };

  const getVehicleColor = (type: string, isEmergency: boolean) => {
    if (isEmergency) {
      if (type.includes('ambulance')) return '#ef4444'; // Red
      if (type.includes('fire')) return '#f97316';     // Orange
      return '#3b82f6';                                // Police Blue
    }
    switch (type) {
      case 'bus': return '#eab308';
      case 'truck': return '#8b5cf6';
      case 'motorcycle': return '#06b6d4';
      default: return '#64748b'; // regular car
    }
  };

  const getVehicleIcon = (type: string) => {
    if (type.includes('ambulance')) return '🚑';
    if (type.includes('fire')) return '🚒';
    if (type.includes('police')) return '🚓';
    if (type === 'bus') return '🚌';
    if (type === 'truck') return '🚚';
    if (type === 'motorcycle') return '🏍️';
    return '🚗';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col items-center relative overflow-hidden">
      
      {/* Visual Canvas Header */}
      <div className="w-full flex items-center justify-between mb-3 text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-semibold text-slate-200">Live Intersection Tracking Canvas</span>
          <span className="text-slate-500">• 4-Lane Real-Time Physics Feed</span>
        </div>
        <div className="flex items-center space-x-3 text-slate-400">
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span>YOLOv8 BBox</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            <span>Emergency Vehicle</span>
          </span>
        </div>
      </div>

      {/* SVG Canvas Workspace (600x600 resolution) */}
      <div className="relative w-full max-w-[580px] aspect-square bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden">
        <svg viewBox="0 0 600 600" className="w-full h-full select-none">
          
          {/* Grass / Ground */}
          <rect x="0" y="0" width="600" height="600" fill="#0f172a" />

          {/* Road Asphalt */}
          {/* Vertical Road */}
          <rect x="220" y="0" width="160" height="600" fill="#1e293b" />
          {/* Horizontal Road */}
          <rect x="0" y="220" width="600" height="160" fill="#1e293b" />

          {/* Road Markings / Lane dividers */}
          {/* North Road Divider */}
          <line x1="300" y1="0" x2="300" y2="200" stroke="#f59e0b" strokeWidth="3" strokeDasharray="10,8" />
          {/* South Road Divider */}
          <line x1="300" y1="400" x2="300" y2="600" stroke="#f59e0b" strokeWidth="3" strokeDasharray="10,8" />
          {/* East Road Divider */}
          <line x1="400" y1="300" x2="600" y2="300" stroke="#f59e0b" strokeWidth="3" strokeDasharray="10,8" />
          {/* West Road Divider */}
          <line x1="0" y1="300" x2="200" y2="300" stroke="#f59e0b" strokeWidth="3" strokeDasharray="10,8" />

          {/* Stop Lines */}
          {/* Lane 1 (North) Stop line */}
          <line x1="220" y1="200" x2="300" y2="200" stroke="#ffffff" strokeWidth="5" />
          {/* Lane 2 (South) Stop line */}
          <line x1="300" y1="400" x2="380" y2="400" stroke="#ffffff" strokeWidth="5" />
          {/* Lane 3 (East) Stop line */}
          <line x1="400" y1="220" x2="400" y2="300" stroke="#ffffff" strokeWidth="5" />
          {/* Lane 4 (West) Stop line */}
          <line x1="200" y1="300" x2="200" y2="380" stroke="#ffffff" strokeWidth="5" />

          {/* Zebra Crossings */}
          {/* North zebra */}
          {Array.from({ length: 6 }).map((_, i) => (
            <rect key={`nz-${i}`} x={230 + i * 24} y="180" width="14" height="15" fill="#e2e8f0" opacity="0.4" />
          ))}
          {/* South zebra */}
          {Array.from({ length: 6 }).map((_, i) => (
            <rect key={`sz-${i}`} x={230 + i * 24} y="405" width="14" height="15" fill="#e2e8f0" opacity="0.4" />
          ))}
          {/* East zebra */}
          {Array.from({ length: 6 }).map((_, i) => (
            <rect key={`ez-${i}`} x="405" y={230 + i * 24} width="15" height="14" fill="#e2e8f0" opacity="0.4" />
          ))}
          {/* West zebra */}
          {Array.from({ length: 6 }).map((_, i) => (
            <rect key={`wz-${i}`} x="180" y={230 + i * 24} width="15" height="14" fill="#e2e8f0" opacity="0.4" />
          ))}

          {/* INTERSECTION BOUNDARY BOX & CLEARANCE ZONE */}
          <rect
            x="200"
            y="200"
            width="200"
            height="200"
            fill={isOverride ? "rgba(244, 63, 94, 0.08)" : "rgba(16, 185, 129, 0.04)"}
            stroke={isOverride ? "#f43f5e" : "#10b981"}
            strokeWidth="2.5"
            strokeDasharray={isOverride ? "6,4" : "4,4"}
            className={isOverride ? "animate-pulse" : ""}
          />

          {/* Intersection Box Corner Labels */}
          <text x="210" y="218" fill={isOverride ? "#f43f5e" : "#64748b"} fontSize="10" fontFamily="monospace">
            CLEARANCE ZONE [200,200]
          </text>
          <text x="390" y="390" textAnchor="end" fill={isOverride ? "#f43f5e" : "#64748b"} fontSize="10" fontFamily="monospace">
            [400,400] EXIT
          </text>

          {/* Lane Arrows & Labels */}
          {/* Lane 1 (North) */}
          <text x="260" y="40" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">LANE 1 (NORTH) ↓</text>
          {/* Lane 2 (South) */}
          <text x="340" y="570" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">LANE 2 (SOUTH) ↑</text>
          {/* Lane 3 (East) */}
          <text x="540" y="260" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">LANE 3 (EAST) ←</text>
          {/* Lane 4 (West) */}
          <text x="60" y="345" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">LANE 4 (WEST) →</text>

          {/* TRAFFIC LIGHT CONTROLLERS (Mounted at stop lines) */}
          
          {/* Lane 1 Signal (Top Left) */}
          <g transform="translate(180, 140)">
            <rect x="0" y="0" width="32" height="54" rx="6" fill="#090d16" stroke="#334155" strokeWidth="1.5" />
            <circle cx="16" cy="12" r="6" fill={getSignalColor(1) === 'RED' ? '#ef4444' : '#1e293b'} />
            <circle cx="16" cy="27" r="6" fill={getSignalColor(1) === 'YELLOW' ? '#eab308' : '#1e293b'} />
            <circle cx="16" cy="42" r="6" fill={getSignalColor(1) === 'GREEN' ? '#10b981' : '#1e293b'} />
            {signals.currentGreenLane === 1 && (
              <text x="16" y="-6" textAnchor="middle" fill="#10b981" fontSize="10" fontWeight="bold">
                {Math.ceil(signals.timerRemaining)}s
              </text>
            )}
          </g>

          {/* Lane 2 Signal (Bottom Right) */}
          <g transform="translate(390, 410)">
            <rect x="0" y="0" width="32" height="54" rx="6" fill="#090d16" stroke="#334155" strokeWidth="1.5" />
            <circle cx="16" cy="12" r="6" fill={getSignalColor(2) === 'RED' ? '#ef4444' : '#1e293b'} />
            <circle cx="16" cy="27" r="6" fill={getSignalColor(2) === 'YELLOW' ? '#eab308' : '#1e293b'} />
            <circle cx="16" cy="42" r="6" fill={getSignalColor(2) === 'GREEN' ? '#10b981' : '#1e293b'} />
            {signals.currentGreenLane === 2 && (
              <text x="16" y="66" textAnchor="middle" fill="#10b981" fontSize="10" fontWeight="bold">
                {Math.ceil(signals.timerRemaining)}s
              </text>
            )}
          </g>

          {/* Lane 3 Signal (Top Right) */}
          <g transform="translate(410, 150)">
            <rect x="0" y="0" width="54" height="32" rx="6" fill="#090d16" stroke="#334155" strokeWidth="1.5" />
            <circle cx="12" cy="16" r="6" fill={getSignalColor(3) === 'RED' ? '#ef4444' : '#1e293b'} />
            <circle cx="27" cy="16" r="6" fill={getSignalColor(3) === 'YELLOW' ? '#eab308' : '#1e293b'} />
            <circle cx="42" cy="16" r="6" fill={getSignalColor(3) === 'GREEN' ? '#10b981' : '#1e293b'} />
            {signals.currentGreenLane === 3 && (
              <text x="62" y="20" fill="#10b981" fontSize="10" fontWeight="bold">
                {Math.ceil(signals.timerRemaining)}s
              </text>
            )}
          </g>

          {/* Lane 4 Signal (Bottom Left) */}
          <g transform="translate(135, 410)">
            <rect x="0" y="0" width="54" height="32" rx="6" fill="#090d16" stroke="#334155" strokeWidth="1.5" />
            <circle cx="12" cy="16" r="6" fill={getSignalColor(4) === 'RED' ? '#ef4444' : '#1e293b'} />
            <circle cx="27" cy="16" r="6" fill={getSignalColor(4) === 'YELLOW' ? '#eab308' : '#1e293b'} />
            <circle cx="42" cy="16" r="6" fill={getSignalColor(4) === 'GREEN' ? '#10b981' : '#1e293b'} />
            {signals.currentGreenLane === 4 && (
              <text x="-12" y="20" textAnchor="end" fill="#10b981" fontSize="10" fontWeight="bold">
                {Math.ceil(signals.timerRemaining)}s
              </text>
            )}
          </g>

          {/* MOVING VEHICLES WITH YOLOv8 BOUNDING BOXES */}
          {vehicles.map((v) => {
            const isEm = v.isEmergency;
            const isTargetActiveEm = v.id === activeEmergencyId;
            const color = getVehicleColor(v.type, isEm);
            const icon = getVehicleIcon(v.type);

            // Bounding box dimensions
            const bw = isEm ? 48 : 36;
            const bh = isEm ? 32 : 24;
            const bx = v.x - bw / 2;
            const by = v.y - bh / 2;

            return (
              <g key={v.id} transform={`translate(${bx}, ${by})`}>
                
                {/* Vehicle body rectangle */}
                <rect
                  x="0"
                  y="0"
                  width={bw}
                  height={bh}
                  rx="6"
                  fill={color}
                  stroke={isEm ? '#ffffff' : '#334155'}
                  strokeWidth={isEm ? '2' : '1'}
                  className="transition-all"
                />

                {/* Vehicle Icon */}
                <text x={bw / 2} y={bh / 2 + 4} textAnchor="middle" fontSize="14">
                  {icon}
                </text>

                {/* YOLOv8 Bounding Box Overlay */}
                <rect
                  x="-4"
                  y="-4"
                  width={bw + 8}
                  height={bh + 8}
                  fill="none"
                  stroke={isEm ? '#f43f5e' : '#06b6d4'}
                  strokeWidth={isTargetActiveEm ? '2.5' : '1.5'}
                  strokeDasharray={isTargetActiveEm ? 'none' : '3,2'}
                  className={isTargetActiveEm ? 'animate-pulse' : ''}
                />

                {/* YOLOv8 Label Tag */}
                <g transform="translate(-4, -18)">
                  <rect
                    x="0"
                    y="0"
                    width={isEm ? 80 : 54}
                    height="13"
                    fill={isEm ? '#f43f5e' : '#06b6d4'}
                    rx="2"
                  />
                  <text
                    x="3"
                    y="10"
                    fill="#ffffff"
                    fontSize="9"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    {v.type.substring(0, 8)} {v.confidence.toFixed(2)}
                  </text>
                </g>

                {/* Siren Glow for Active Emergency */}
                {isTargetActiveEm && (
                  <circle cx={bw / 2} cy={bh / 2} r="28" fill="rgba(244,63,94,0.2)" className="animate-ping" pointerEvents="none" />
                )}

              </g>
            );
          })}

        </svg>

        {/* Override Overlay Banner inside canvas */}
        {isOverride && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-rose-950/90 border border-rose-500/80 text-rose-200 px-3.5 py-1.5 rounded-full text-xs font-bold flex items-center space-x-2 shadow-lg backdrop-blur-md animate-bounce">
            <ShieldAlert className="w-4 h-4 text-rose-400" />
            <span>EMERGENCY OVERRIDE • GREEN LOCKED FOR LANE {activeLane}</span>
          </div>
        )}

      </div>

    </div>
  );
};
