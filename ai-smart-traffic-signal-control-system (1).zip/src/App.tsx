import { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { ClearanceBanner } from './components/ClearanceBanner';
import { IntersectionCanvas } from './components/IntersectionCanvas';
import { DashboardPanel } from './components/DashboardPanel';
import { SystemLogs } from './components/SystemLogs';
import { PythonCodeViewer } from './components/PythonCodeViewer';

import {
  Vehicle,
  LaneId,
  SignalStatus,
  EmergencyDashboardState,
  EmergencyVehicleData,
  LogEntry
} from './types';

export default function App() {
  // Navigation Tab: 'sim' | 'code' | 'logs'
  const [activeTab, setActiveTab] = useState<'sim' | 'code' | 'logs'>('sim');

  // Simulation Clock state
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Clearance Notification Banner
  const [clearanceBanner, setClearanceBanner] = useState<string | null>(null);

  // System Event Logs
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'init-1',
      timestamp: new Date().toLocaleTimeString(),
      category: 'SYSTEM',
      message: '🚦 AI Smart Traffic Signal Control System initialized under AI Dynamic Control Mode.'
    },
    {
      id: 'init-2',
      timestamp: new Date().toLocaleTimeString(),
      category: 'DENSITY',
      message: '📷 YOLOv8 Vehicle Detection Engine active. Monitoring Lane 1-4 vehicle density.'
    }
  ]);

  // Traffic Signals State
  const [signals, setSignals] = useState<SignalStatus>({
    signalMode: 'AI Dynamic Control',
    currentGreenLane: 1,
    laneSignals: { 1: 'GREEN', 2: 'RED', 3: 'RED', 4: 'RED' },
    timerRemaining: 15.0,
    isYellow: false
  });

  // Emergency Management State
  const [emergencyState, setEmergencyState] = useState<EmergencyDashboardState>({
    emergencyStatus: 'INACTIVE',
    aiDetection: 'ACTIVE',
    signalMode: 'AI Dynamic Control',
    activeEmergency: null,
    queue: [],
    recentNotification: null
  });

  // Simulated Vehicles List
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  // Internal vehicle counter
  const vehicleIdCounter = useRef<number>(100);

  // Vehicle Density per lane
  const laneCounts: Record<LaneId, number> = {
    1: vehicles.filter(v => v.lane === 1 && !v.isEmergency).length,
    2: vehicles.filter(v => v.lane === 2 && !v.isEmergency).length,
    3: vehicles.filter(v => v.lane === 3 && !v.isEmergency).length,
    4: vehicles.filter(v => v.lane === 4 && !v.isEmergency).length,
  };

  const addLog = useCallback((category: LogEntry['category'], message: string) => {
    const entry: LogEntry = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: new Date().toLocaleTimeString(),
      category,
      message
    };
    setLogs((prev) => [entry, ...prev.slice(0, 49)]);
  }, []);

  // Initial population of regular vehicles
  useEffect(() => {
    const initialVehicles: Vehicle[] = [
      { id: 'v_1', type: 'car', lane: 1, x: 260, y: 80, speed: 1.8, isEmergency: false, status: 'approaching', bbox: [242, 68, 278, 92], confidence: 0.95 },
      { id: 'v_2', type: 'bus', lane: 1, x: 260, y: 30, speed: 1.5, isEmergency: false, status: 'approaching', bbox: [242, 10, 278, 50], confidence: 0.98 },
      { id: 'v_3', type: 'car', lane: 2, x: 340, y: 520, speed: 1.8, isEmergency: false, status: 'approaching', bbox: [322, 508, 358, 532], confidence: 0.92 },
      { id: 'v_4', type: 'truck', lane: 3, x: 550, y: 260, speed: 1.4, isEmergency: false, status: 'approaching', bbox: [532, 248, 568, 272], confidence: 0.96 },
      { id: 'v_5', type: 'car', lane: 4, x: 60, y: 340, speed: 1.8, isEmergency: false, status: 'approaching', bbox: [42, 328, 78, 352], confidence: 0.91 }
    ];
    setVehicles(initialVehicles);
  }, []);

  // Dispatch Emergency Vehicle Handler
  const handleDispatchEmergency = useCallback((type: 'Ambulance' | 'Fire Truck' | 'Police Vehicle', lane: LaneId) => {
    vehicleIdCounter.current += 1;
    const evId = `EV_${type.substring(0, 3).toUpperCase()}_${vehicleIdCounter.current}`;

    let startX = 260;
    let startY = 20;

    if (lane === 1) { startX = 260; startY = 10; }
    else if (lane === 2) { startX = 340; startY = 590; }
    else if (lane === 3) { startX = 590; startY = 260; }
    else if (lane === 4) { startX = 10; startY = 340; }

    const newSimVehicle: Vehicle = {
      id: evId,
      type: type === 'Ambulance' ? 'ambulance' : type === 'Fire Truck' ? 'fire_truck' : 'police',
      lane,
      x: startX,
      y: startY,
      speed: 3.5, // Move faster
      isEmergency: true,
      status: 'approaching',
      bbox: [startX - 24, startY - 16, startX + 24, startY + 16],
      confidence: 0.98
    };

    const evData: EmergencyVehicleData = {
      id: evId,
      type,
      lane,
      status: 'crossing',
      bbox: [startX - 24, startY - 16, startX + 24, startY + 16],
      position: { x: startX, y: startY }
    };

    setVehicles((prev) => [...prev, newSimVehicle]);

    setEmergencyState((prev) => {
      if (prev.emergencyStatus === 'ACTIVE' || prev.activeEmergency !== null) {
        // Queue emergency vehicle (Requirement #9)
        addLog('QUEUE', `⏳ Emergency Vehicle Queued: ${type} (${evId}) queued for Lane ${lane}. Queue position: ${prev.queue.length + 1}`);
        return {
          ...prev,
          queue: [...prev.queue, evData]
        };
      } else {
        // Activate Emergency Override immediately (Requirements #1, #2, #3)
        addLog('OVERRIDE', `🚨 EMERGENCY OVERRIDE ACTIVATED: ${type} (${evId}) detected in Lane ${lane}! Green signal locked on Lane ${lane}.`);
        
        // Lock signals for target lane
        setSignals((prevSig) => ({
          ...prevSig,
          signalMode: 'Emergency Override',
          currentGreenLane: lane,
          laneSignals: {
            1: lane === 1 ? 'GREEN' : 'RED',
            2: lane === 2 ? 'GREEN' : 'RED',
            3: lane === 3 ? 'GREEN' : 'RED',
            4: lane === 4 ? 'GREEN' : 'RED',
          }
        }));

        return {
          ...prev,
          emergencyStatus: 'ACTIVE',
          aiDetection: 'PAUSED',
          signalMode: 'Emergency Override',
          activeEmergency: evData
        };
      }
    });
  }, [addLog]);

  // Demo: Dispatch 2 emergency vehicles in rapid succession to demonstrate queueing! (Requirement #9)
  const handleDispatchQueueDemo = useCallback(() => {
    handleDispatchEmergency('Ambulance', 1);
    setTimeout(() => {
      handleDispatchEmergency('Fire Truck', 3);
    }, 400);
  }, [handleDispatchEmergency]);

  // Add Regular Traffic
  const handleAddTraffic = useCallback(() => {
    const types: Vehicle['type'][] = ['car', 'car', 'bus', 'truck', 'motorcycle'];
    const newVehs: Vehicle[] = [];

    for (let i = 0; i < 5; i++) {
      vehicleIdCounter.current += 1;
      const lane = ((i % 4) + 1) as LaneId;
      const type = types[Math.floor(Math.random() * types.length)];
      
      let x = 260, y = 20;
      if (lane === 1) { x = 260; y = Math.random() * 100; }
      else if (lane === 2) { x = 340; y = 500 + Math.random() * 80; }
      else if (lane === 3) { x = 500 + Math.random() * 80; y = 260; }
      else if (lane === 4) { x = Math.random() * 100; y = 340; }

      newVehs.push({
        id: `v_${vehicleIdCounter.current}`,
        type,
        lane,
        x,
        y,
        speed: 1.5 + Math.random() * 0.8,
        isEmergency: false,
        status: 'approaching',
        bbox: [x - 18, y - 12, x + 18, y + 12],
        confidence: Number((0.88 + Math.random() * 0.1).toFixed(2))
      });
    }

    setVehicles((prev) => [...prev, ...newVehs]);
    addLog('DENSITY', '🚗 Added 5 regular vehicles to traffic stream. Updating YOLOv8 density counts.');
  }, [addLog]);

  // Main Physics & Automatic Clearance Clock Loop
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setVehicles((prevVehicles) => {
        let activeEv = emergencyState.activeEmergency;
        let clearanceTriggered = false;

        const updated = prevVehicles.map((v) => {
          let shouldStop = false;

          // Standard vehicles stop at red stop line
          if (!v.isEmergency) {
            const laneSig = signals.laneSignals[v.lane];
            if (laneSig === 'RED') {
              if (v.lane === 1 && v.y >= 160 && v.y <= 195) shouldStop = true;
              if (v.lane === 2 && v.y <= 440 && v.y >= 405) shouldStop = true;
              if (v.lane === 3 && v.x <= 440 && v.x >= 405) shouldStop = true;
              if (v.lane === 4 && v.x >= 160 && v.x <= 195) shouldStop = true;
            }
          }

          let newX = v.x;
          let newY = v.y;

          if (!shouldStop) {
            if (v.lane === 1) newY += v.speed * 1.5;      // Move South
            else if (v.lane === 2) newY -= v.speed * 1.5; // Move North
            else if (v.lane === 3) newX -= v.speed * 1.5; // Move West
            else if (v.lane === 4) newX += v.speed * 1.5; // Move East
          }

          // Bounding box calculation
          const bw = v.isEmergency ? 48 : 36;
          const bh = v.isEmergency ? 32 : 24;
          const bbox: [number, number, number, number] = [
            newX - bw / 2,
            newY - bh / 2,
            newX + bw / 2,
            newY + bh / 2
          ];

          // Check intersection clearance for active emergency vehicle
          // Clearance zone box: [200, 200] to [400, 400]
          if (v.isEmergency && activeEv && v.id === activeEv.id) {
            let exited = false;

            if (v.lane === 1 && newY > 410) exited = true;        // North -> South exit when y > 410
            else if (v.lane === 2 && newY < 190) exited = true;   // South -> North exit when y < 190
            else if (v.lane === 3 && newX < 190) exited = true;   // East -> West exit when x < 190
            else if (v.lane === 4 && newX > 410) exited = true;   // West -> East exit when x > 410

            if (exited) {
              clearanceTriggered = true;
            }
          }

          return {
            ...v,
            x: newX,
            y: newY,
            bbox
          };
        }).filter((v) => v.x >= -100 && v.x <= 700 && v.y >= -100 && v.y <= 700);

        // Process Automatic Clearance Event
        if (clearanceTriggered && activeEv) {
          const clearedEvId = activeEv.id;
          
          setEmergencyState((prevEm) => {
            if (prevEm.queue.length > 0) {
              // Process next queued emergency vehicle (Requirement #9)
              const [nextEv, ...remainingQueue] = prevEm.queue;

              addLog('CLEARANCE', `✅ Emergency Cleared for ${activeEv?.type} (${clearedEvId}). Processing next queued vehicle: ${nextEv.type} in Lane ${nextEv.lane}.`);

              setSignals((prevSig) => ({
                ...prevSig,
                signalMode: 'Emergency Override',
                currentGreenLane: nextEv.lane,
                laneSignals: {
                  1: nextEv.lane === 1 ? 'GREEN' : 'RED',
                  2: nextEv.lane === 2 ? 'GREEN' : 'RED',
                  3: nextEv.lane === 3 ? 'GREEN' : 'RED',
                  4: nextEv.lane === 4 ? 'GREEN' : 'RED',
                }
              }));

              return {
                ...prevEm,
                activeEmergency: nextEv,
                queue: remainingQueue
              };
            } else {
              // All emergencies cleared! Fully automatic transition back to AI Dynamic Control (Requirements #6, #7, #8, #10, #11)
              const bannerText = "✅ Emergency Cleared – AI Traffic Control Resumed";
              setClearanceBanner(bannerText);

              addLog('CLEARANCE', bannerText);
              addLog('SYSTEM', '🤖 AI Dynamic Control restored. YOLOv8 vehicle detection & lane-wise counting restarted.');

              // Reset Signals
              setSignals((prevSig) => ({
                ...prevSig,
                signalMode: 'AI Dynamic Control',
                currentGreenLane: 1,
                laneSignals: { 1: 'GREEN', 2: 'RED', 3: 'RED', 4: 'RED' },
                timerRemaining: 15.0
              }));

              return {
                ...prevEm,
                emergencyStatus: 'INACTIVE',
                aiDetection: 'ACTIVE',
                signalMode: 'AI Dynamic Control',
                activeEmergency: null,
                recentNotification: bannerText
              };
            }
          });
        }

        return updated;
      });

      // Update AI Dynamic Control Traffic Light Timers when NOT in override
      if (signals.signalMode === 'AI Dynamic Control') {
        setSignals((prevSig) => {
          let rem = prevSig.timerRemaining - 0.1;
          if (rem <= 0) {
            // Rotate green light based on density or cycle
            const nextLane = ((prevSig.currentGreenLane % 4) + 1) as LaneId;
            const currentLaneCount = laneCounts[nextLane] || 0;
            const dynamicDuration = Math.max(8, Math.min(45, 8 + currentLaneCount * 2));

            return {
              ...prevSig,
              currentGreenLane: nextLane,
              timerRemaining: dynamicDuration,
              laneSignals: {
                1: nextLane === 1 ? 'GREEN' : 'RED',
                2: nextLane === 2 ? 'GREEN' : 'RED',
                3: nextLane === 3 ? 'GREEN' : 'RED',
                4: nextLane === 4 ? 'GREEN' : 'RED',
              }
            };
          }
          return { ...prevSig, timerRemaining: rem };
        });
      }

    }, 100);

    return () => clearInterval(interval);
  }, [isPaused, signals.signalMode, signals.laneSignals, emergencyState.activeEmergency, addLog, laneCounts]);

  const handleResetSim = () => {
    setVehicles([]);
    setClearanceBanner(null);
    setEmergencyState({
      emergencyStatus: 'INACTIVE',
      aiDetection: 'ACTIVE',
      signalMode: 'AI Dynamic Control',
      activeEmergency: null,
      queue: [],
      recentNotification: null
    });
    setSignals({
      signalMode: 'AI Dynamic Control',
      currentGreenLane: 1,
      laneSignals: { 1: 'GREEN', 2: 'RED', 3: 'RED', 4: 'RED' },
      timerRemaining: 15.0,
      isYellow: false
    });
    addLog('SYSTEM', '🔄 System simulation state reset.');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white flex flex-col">
      
      {/* Top App Bar Header */}
      <Header
        emergencyStatus={emergencyState.emergencyStatus}
        aiDetection={emergencyState.aiDetection}
        signalMode={emergencyState.signalMode}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isPaused={isPaused}
        togglePause={() => setIsPaused(!isPaused)}
        resetSim={handleResetSim}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Requirement #7 Banner Notification */}
        <ClearanceBanner
          message={clearanceBanner}
          onDismiss={() => setClearanceBanner(null)}
        />

        {/* Tab 1: Interactive Simulation & Dashboard */}
        {activeTab === 'sim' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left 6 columns: Visual Intersection Canvas */}
            <div className="lg:col-span-6">
              <IntersectionCanvas
                vehicles={vehicles}
                signals={signals}
                activeEmergencyId={emergencyState.activeEmergency?.id || null}
                activeLane={emergencyState.activeEmergency?.lane || null}
              />
            </div>

            {/* Right 6 columns: Dashboard Status & Dispatch Controls */}
            <div className="lg:col-span-6 space-y-6">
              <DashboardPanel
                emergencyState={emergencyState}
                signals={signals}
                laneCounts={laneCounts}
                onDispatchEmergency={handleDispatchEmergency}
                onDispatchQueueDemo={handleDispatchQueueDemo}
                onAddTraffic={handleAddTraffic}
              />
            </div>

          </div>
        )}

        {/* Tab 2: Python Source Code Viewer & Documentation */}
        {activeTab === 'code' && (
          <PythonCodeViewer />
        )}

        {/* Tab 3: System Event Logs & Audit Trail */}
        {activeTab === 'logs' && (
          <SystemLogs
            logs={logs}
            onClearLogs={() => setLogs([])}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/60 py-4 text-center text-xs text-slate-500">
        <p>AI-Based Smart Traffic Signal Control System • Autonomous Emergency Vehicle Management & YOLOv8 Decision Engine</p>
      </footer>

    </div>
  );
}
