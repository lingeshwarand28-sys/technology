export type VehicleType = 'car' | 'bus' | 'truck' | 'motorcycle' | 'ambulance' | 'fire_truck' | 'police';

export type LaneId = 1 | 2 | 3 | 4; // 1: North, 2: South, 3: East, 4: West

export type SignalColor = 'GREEN' | 'YELLOW' | 'RED';

export interface Vehicle {
  id: string;
  type: VehicleType;
  lane: LaneId;
  x: number;
  y: number;
  speed: number;
  isEmergency: boolean;
  status: 'approaching' | 'crossing' | 'cleared';
  bbox: [number, number, number, number]; // [x1, y1, x2, y2]
  confidence: number;
}

export interface EmergencyVehicleData {
  id: string;
  type: string;
  lane: LaneId;
  status: 'approaching' | 'crossing' | 'cleared';
  bbox: [number, number, number, number];
  position: { x: number; y: number };
}

export interface SignalStatus {
  signalMode: 'AI Dynamic Control' | 'Emergency Override';
  currentGreenLane: LaneId;
  laneSignals: Record<LaneId, SignalColor>;
  timerRemaining: number;
  isYellow: boolean;
}

export interface EmergencyDashboardState {
  emergencyStatus: 'ACTIVE' | 'INACTIVE';
  aiDetection: 'ACTIVE' | 'PAUSED';
  signalMode: 'AI Dynamic Control' | 'Emergency Override';
  activeEmergency: EmergencyVehicleData | null;
  queue: EmergencyVehicleData[];
  recentNotification: string | null;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  category: 'CLEARANCE' | 'OVERRIDE' | 'QUEUE' | 'DENSITY' | 'SYSTEM';
  message: string;
}

export interface PythonCodeFile {
  filename: string;
  description: string;
  code: string;
}
