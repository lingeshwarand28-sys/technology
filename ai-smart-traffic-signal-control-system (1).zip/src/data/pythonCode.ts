import { PythonCodeFile } from '../types';

export const pythonCodeFiles: PythonCodeFile[] = [
  {
    filename: 'emergency.py',
    description: 'Emergency Vehicle Management Engine. Handles instant Emergency Override activation, position & bounding box clearance tracking, queueing, and automatic restoration.',
    code: `"""
emergency.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Emergency Vehicle Management Module
===============================================================================

This module handles:
1. Detection and registration of emergency vehicles (Ambulance, Fire Truck, Police).
2. Emergency Override Mode activation and lane signal locking.
3. Continuous tracking of emergency vehicle bounding boxes and positions.
4. Automatic intersection clearance detection using spatial bounding box coordinates.
5. Automatic reset of emergency override, flag resetting, queue processing, and system restoration.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict
import time


@dataclass
class EmergencyVehicle:
    """Dataclass representing an emergency vehicle inside the detection workspace."""
    vehicle_id: str
    vehicle_type: str  # 'Ambulance', 'Fire Truck', or 'Police Vehicle'
    lane_id: int       # 1: North, 2: South, 3: East, 4: West
    bbox: Tuple[float, float, float, float]  # [x1, y1, x2, y2]
    confidence: float
    position: Tuple[float, float]  # (x, y) center position
    speed: float = 30.0  # speed in km/h or pixels/sec
    status: str = "approaching"  # 'approaching', 'crossing', 'cleared'
    timestamp: float = field(default_factory=time.time)

    @property
    def center_x(self) -> float:
        return (self.bbox[0] + self.bbox[2]) / 2.0

    @property
    def center_y(self) -> float:
        return (self.bbox[1] + self.bbox[3]) / 2.0


class EmergencyManager:
    """
    Automatic Emergency Vehicle Management Engine.
    Handles queueing, active override, continuous tracking, bounding box clearance,
    and automatic transition back to AI Dynamic Control.
    """

    def __init__(self, intersection_bounds: Optional[Dict[str, float]] = None):
        # Intersection bounding coordinates [x_min, x_max, y_min, y_max]
        self.intersection_bounds = intersection_bounds or {
            "x_min": 200.0,
            "x_max": 600.0,
            "y_min": 200.0,
            "y_max": 600.0
        }
        
        self.active_emergency: Optional[EmergencyVehicle] = None
        self.emergency_queue: List[EmergencyVehicle] = []
        self.override_active: bool = False
        self.active_lane: Optional[int] = None
        
        # System Notification Log
        self.notifications: List[Dict[str, str]] = []
        self.cleared_history: List[EmergencyVehicle] = []

    def register_emergency_vehicle(self, vehicle: EmergencyVehicle) -> Dict[str, str]:
        """
        Registers a detected emergency vehicle.
        If no emergency is active, immediately activates Emergency Override Mode.
        If an emergency is already active, queues the vehicle for subsequent processing.
        """
        if not self.override_active and self.active_emergency is None:
            # Activate Emergency Override immediately
            self.active_emergency = vehicle
            self.override_active = True
            self.active_lane = vehicle.lane_id
            vehicle.status = "crossing"
            
            msg = f"🚨 EMERGENCY OVERRIDE ACTIVATED: {vehicle.vehicle_type} ({vehicle.vehicle_id}) detected in Lane {vehicle.lane_id}!"
            self._add_notification(msg, category="EMERGENCY_START")
            return {
                "action": "OVERRIDE_ACTIVATED",
                "message": msg,
                "lane_id": vehicle.lane_id,
                "vehicle": vehicle.vehicle_type
            }
        else:
            # Check if vehicle is already in queue or active to prevent duplicates
            is_active = self.active_emergency and self.active_emergency.vehicle_id == vehicle.vehicle_id
            is_queued = any(v.vehicle_id == vehicle.vehicle_id for v in self.emergency_queue)
            
            if not is_active and not is_queued:
                self.emergency_queue.append(vehicle)
                msg = f"⏳ Emergency Vehicle Queued: {vehicle.vehicle_type} ({vehicle.vehicle_id}) queued for Lane {vehicle.lane_id}. Queue position: {len(self.emergency_queue)}"
                self._add_notification(msg, category="QUEUE_ADDED")
                return {
                    "action": "QUEUED",
                    "message": msg,
                    "queue_position": len(self.emergency_queue)
                }
            
            return {"action": "DUPLICATE_IGNORED", "message": "Vehicle already tracked."}

    def update_vehicle_position(self, vehicle_id: str, new_bbox: Tuple[float, float, float, float], current_lane: int) -> Dict[str, any]:
        """
        Continuously updates position & bounding box of active emergency vehicle.
        Evaluates if the vehicle has completely passed through the intersection.
        """
        if not self.active_emergency or self.active_emergency.vehicle_id != vehicle_id:
            return {"status": "NO_MATCHING_ACTIVE_EMERGENCY"}

        # Update position
        self.active_emergency.bbox = new_bbox
        self.active_emergency.lane_id = current_lane
        self.active_emergency.position = (self.active_emergency.center_x, self.active_emergency.center_y)

        # Check if vehicle has completely exited the intersection
        has_cleared = self._check_intersection_clearance(self.active_emergency)

        if has_cleared:
            return self.process_emergency_clearance()

        return {
            "status": "TRACKING",
            "lane_id": self.active_emergency.lane_id,
            "center": self.active_emergency.position,
            "vehicle_status": self.active_emergency.status
        }

    def _check_intersection_clearance(self, vehicle: EmergencyVehicle) -> bool:
        """
        Determines if an emergency vehicle's bounding box has completely crossed
        and exited the intersection polygon based on its travel direction (lane).
        """
        x1, y1, x2, y2 = vehicle.bbox
        cx, cy = vehicle.center_x, vehicle.center_y
        bounds = self.intersection_bounds

        # Lane 1 (North -> South): Exit when top bound y1 > y_max
        if vehicle.lane_id == 1:
            return y1 > bounds["y_max"]

        # Lane 2 (South -> North): Exit when bottom bound y2 < y_min
        elif vehicle.lane_id == 2:
            return y2 < bounds["y_min"]

        # Lane 3 (East -> West): Exit when right bound x2 < x_min
        elif vehicle.lane_id == 3:
            return x2 < bounds["x_min"]

        # Lane 4 (West -> East): Exit when left bound x1 > x_max
        elif vehicle.lane_id == 4:
            return x1 > bounds["x_max"]

        # Default fallback: check if center point is completely outside bounds
        is_outside = (cx < bounds["x_min"] or cx > bounds["x_max"] or
                      cy < bounds["y_min"] or cy > bounds["y_max"])
        return is_outside

    def process_emergency_clearance(self) -> Dict[str, any]:
        """
        Executes automatic clearance workflow:
        1. Resets emergency flags.
        2. Removes cleared vehicle from active emergency list.
        3. Posts notification "✅ Emergency Cleared – AI Traffic Control Resumed".
        4. Checks emergency queue for waiting emergency vehicles.
        5. If queue is non-empty, immediately processes next emergency.
        6. Otherwise, safely transitions system back to AI Dynamic Control mode.
        """
        cleared_ev = self.active_emergency
        if cleared_ev:
            cleared_ev.status = "cleared"
            self.cleared_history.append(cleared_ev)

        # Reset active flags
        self.active_emergency = None
        self.override_active = False
        self.active_lane = None

        cleared_msg = "✅ Emergency Cleared – AI Traffic Control Resumed"
        self._add_notification(cleared_msg, category="CLEARANCE")

        # Check if another emergency vehicle is waiting in queue (Requirement #9)
        if len(self.emergency_queue) > 0:
            next_ev = self.emergency_queue.pop(0)
            queue_msg = f"🔄 Processing Queued Emergency Vehicle: {next_ev.vehicle_type} ({next_ev.vehicle_id}) in Lane {next_ev.lane_id}"
            self._add_notification(queue_msg, category="QUEUE_DISPATCH")
            
            # Activate next emergency vehicle automatically
            self.active_emergency = next_ev
            self.override_active = True
            self.active_lane = next_ev.lane_id
            next_ev.status = "crossing"
            
            return {
                "status": "NEXT_EMERGENCY_ACTIVATED",
                "cleared_vehicle": cleared_ev.vehicle_id if cleared_ev else None,
                "next_vehicle": next_ev,
                "lane_id": next_ev.lane_id,
                "message": f"{cleared_msg} | {queue_msg}"
            }

        return {
            "status": "ALL_EMERGENCIES_CLEARED",
            "cleared_vehicle": cleared_ev.vehicle_id if cleared_ev else None,
            "message": cleared_msg,
            "dashboard_updates": {
                "emergency_status": "INACTIVE",
                "ai_detection": "ACTIVE",
                "signal_mode": "AI Dynamic Control"
            }
        }

    def _add_notification(self, text: str, category: str = "INFO"):
        self.notifications.append({
            "timestamp": time.strftime("%H:%M:%S"),
            "category": category,
            "message": text
        })

    def get_dashboard_state(self) -> Dict[str, any]:
        """Returns emergency management metrics for dashboard display."""
        return {
            "emergency_status": "ACTIVE" if self.override_active else "INACTIVE",
            "ai_detection": "PAUSED (Override)" if self.override_active else "ACTIVE",
            "signal_mode": "Emergency Override" if self.override_active else "AI Dynamic Control",
            "active_emergency_vehicle": {
                "id": self.active_emergency.vehicle_id,
                "type": self.active_emergency.vehicle_type,
                "lane": self.active_emergency.lane_id,
                "status": self.active_emergency.status
            } if self.active_emergency else None,
            "queued_count": len(self.emergency_queue),
            "queue_summary": [f"{v.vehicle_type} (Lane {v.lane_id})" for v in self.emergency_queue],
            "recent_notification": self.notifications[-1]["message"] if self.notifications else None
        }
`
  },
  {
    filename: 'traffic_controller.py',
    description: 'Traffic Signal Controller & AI Decision Engine. Dynamically allocates signal timing based on vehicle density, or locks signal green for emergency vehicle lane while red for all other lanes.',
    code: `"""
traffic_controller.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Traffic Signal Controller & Decision Engine
===============================================================================

This module handles:
1. Signal state allocation (GREEN, YELLOW, RED) across 4 intersection lanes.
2. AI Dynamic Decision Engine for vehicle density-based signal timing.
3. Instant Emergency Override Signal Lock (Green for emergency lane, Red for all others).
4. Automatic transition & signal resumption back to AI Dynamic Control upon clearance.
"""

from typing import Dict, List, Optional
import time


class SignalState:
    GREEN = "GREEN"
    YELLOW = "YELLOW"
    RED = "RED"


class TrafficSignalController:
    """
    Traffic Signal Controller & AI Decision Engine.
    Allocates signal timing based on YOLOv8 vehicle density counts during normal operations,
    or locks signals in Emergency Override Mode when an emergency vehicle is detected.
    """

    def __init__(self, lanes: List[int] = None):
        self.lanes = lanes or [1, 2, 3, 4]  # 1: North, 2: South, 3: East, 4: West
        self.signal_mode = "AI Dynamic Control"  # 'AI Dynamic Control' or 'Emergency Override'
        
        # Current signal state for each lane
        self.lane_signals: Dict[int, str] = {
            1: SignalState.GREEN,
            2: SignalState.RED,
            3: SignalState.RED,
            4: SignalState.RED
        }

        self.current_green_lane: int = 1
        self.green_timer_remaining: float = 15.0
        self.yellow_timer_remaining: float = 0.0
        self.is_yellow_phase: bool = False
        
        # Timing constants
        self.MIN_GREEN_TIME = 8.0     # Minimum green light duration (seconds)
        self.MAX_GREEN_TIME = 45.0    # Maximum green light duration (seconds)
        self.SEC_PER_VEHICLE = 2.0    # Allocated time per vehicle detected by YOLOv8
        self.YELLOW_TIME = 3.0         # Transition yellow light duration
        
        # Last known vehicle density per lane
        self.lane_densities: Dict[int, int] = {1: 0, 2: 0, 3: 0, 4: 0}

    def set_emergency_override(self, emergency_lane: int):
        """
        Activates Emergency Override Mode:
        - Sets signal_mode = 'Emergency Override'
        - Instantly sets target emergency_lane = GREEN
        - Sets ALL other lanes = RED
        """
        self.signal_mode = "Emergency Override"
        self.current_green_lane = emergency_lane
        self.is_yellow_phase = False
        self.yellow_timer_remaining = 0.0

        for lane in self.lanes:
            if lane == emergency_lane:
                self.lane_signals[lane] = SignalState.GREEN
            else:
                self.lane_signals[lane] = SignalState.RED

        print(f"[TrafficController] Emergency Override Activated! Lane {emergency_lane} set to GREEN. All other lanes locked to RED.")

    def resume_ai_dynamic_control(self, lane_counts: Optional[Dict[int, int]] = None):
        """
        Restores AI Dynamic Control Mode:
        - Sets signal_mode = 'AI Dynamic Control'
        - Recalculates dynamic green time for current green lane or highest-density lane
        - Resumes normal decision engine cycle
        """
        self.signal_mode = "AI Dynamic Control"
        if lane_counts:
            self.lane_densities.update(lane_counts)

        # Select highest density lane or cycle to next lane
        next_lane = self._calculate_highest_density_lane()
        self.current_green_lane = next_lane
        self.green_timer_remaining = self.calculate_dynamic_green_time(self.lane_densities.get(next_lane, 0))
        self.is_yellow_phase = False

        for lane in self.lanes:
            if lane == next_lane:
                self.lane_signals[lane] = SignalState.GREEN
            else:
                self.lane_signals[lane] = SignalState.RED

        print(f"[TrafficController] AI Dynamic Control Resumed. Active Green Lane: Lane {next_lane} ({self.green_timer_remaining:.1f}s)")

    def calculate_dynamic_green_time(self, vehicle_count: int) -> float:
        """
        Decision Engine: Dynamically calculates green signal duration based on lane vehicle density.
        Formula: Green Duration = max(MIN_GREEN, min(MAX_GREEN, MIN_GREEN + (Count * SEC_PER_VEHICLE)))
        """
        allocated_time = self.MIN_GREEN_TIME + (vehicle_count * self.SEC_PER_VEHICLE)
        return max(self.MIN_GREEN_TIME, min(self.MAX_GREEN_TIME, allocated_time))

    def update_cycle(self, dt: float, lane_counts: Dict[int, int]):
        """
        Advances the traffic signal clock by \`dt\` seconds.
        In 'AI Dynamic Control' mode, manages countdown timers and rotates green signal.
        In 'Emergency Override' mode, locks emergency lane to GREEN and ignores normal rotation.
        """
        self.lane_densities.update(lane_counts)

        if self.signal_mode == "Emergency Override":
            # Emergency Mode: keep emergency lane GREEN and freeze AI timer rotation
            return

        # AI Dynamic Control Mode
        if self.is_yellow_phase:
            self.yellow_timer_remaining -= dt
            if self.yellow_timer_remaining <= 0:
                self.is_yellow_phase = False
                # Rotate to next green lane based on density or round-robin
                self.current_green_lane = self._calculate_highest_density_lane()
                self.green_timer_remaining = self.calculate_dynamic_green_time(
                    self.lane_densities.get(self.current_green_lane, 0)
                )
                
                for lane in self.lanes:
                    if lane == self.current_green_lane:
                        self.lane_signals[lane] = SignalState.GREEN
                    else:
                        self.lane_signals[lane] = SignalState.RED
        else:
            self.green_timer_remaining -= dt
            if self.green_timer_remaining <= 0:
                # Transition current green lane to yellow
                self.is_yellow_phase = True
                self.yellow_timer_remaining = self.YELLOW_TIME
                self.lane_signals[self.current_green_lane] = SignalState.YELLOW

    def _calculate_highest_density_lane(self) -> int:
        """
        Selects lane with highest vehicle count.
        If all equal or zero, rotates sequentially to next lane.
        """
        max_count = -1
        selected_lane = self.current_green_lane

        # Check candidate lanes other than current green lane first
        candidates = [l for l in self.lanes if l != self.current_green_lane]
        for lane in candidates:
            count = self.lane_densities.get(lane, 0)
            if count > max_count and count > 0:
                max_count = count
                selected_lane = lane

        # Fallback to sequential round-robin
        if max_count <= 0:
            current_idx = self.lanes.index(self.current_green_lane)
            selected_lane = self.lanes[(current_idx + 1) % len(self.lanes)]

        return selected_lane

    def get_signal_status(self) -> Dict[str, any]:
        """Returns signal controller state summary for UI/Dashboard."""
        return {
            "signal_mode": self.signal_mode,
            "current_green_lane": self.current_green_lane,
            "lane_signals": self.lane_signals,
            "timer_remaining": round(self.yellow_timer_remaining if self.is_yellow_phase else self.green_timer_remaining, 1),
            "is_yellow": self.is_yellow_phase,
            "lane_densities": self.lane_densities
        }
`
  },
  {
    filename: 'detector.py',
    description: 'YOLOv8 Vehicle Detector & Lane Counting Engine. Identifies vehicle types and emergency vehicles, maintains active/paused detection state, and feeds counts to Decision Engine.',
    code: `"""
detector.py
===============================================================================
AI-Based Smart Traffic Signal Control System - YOLOv8 Vehicle Detector Module
===============================================================================

This module handles:
1. YOLOv8 object detection simulation for multi-lane vehicle recognition.
2. Recognition of regular traffic (Cars, Buses, Trucks, Motorcycles).
3. Instant detection and bounding box tagging for Emergency Vehicles (Ambulance, Fire Truck, Police).
4. Lane-wise vehicle density counting.
5. Pause / Restart controls for YOLOv8 vehicle detection state.
"""

from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import random


@dataclass
class DetectedObject:
    """Dataclass for YOLOv8 detected vehicle object."""
    object_id: str
    class_name: str     # 'car', 'bus', 'truck', 'motorcycle', 'ambulance', 'fire_truck', 'police'
    confidence: float   # 0.0 - 1.0
    lane_id: int        # 1: North, 2: South, 3: East, 4: West
    bbox: Tuple[float, float, float, float]  # [x1, y1, x2, y2]
    is_emergency: bool


class YOLOv8VehicleDetector:
    """
    YOLOv8 Object Detection Engine for Real-Time Traffic Analysis.
    Performs lane-wise vehicle counting and scans for emergency vehicle classes.
    """

    EMERGENCY_CLASSES = ["ambulance", "fire_truck", "police", "police_vehicle"]

    def __init__(self, confidence_threshold: float = 0.5):
        self.confidence_threshold = confidence_threshold
        self.ai_detection_active: bool = True
        self.last_detection_summary: Dict[int, int] = {1: 0, 2: 0, 3: 0, 4: 0}

    def pause_detection(self):
        """Pauses normal vehicle counting (e.g. during emergency override mode if bypassed)."""
        self.ai_detection_active = False
        print("[Detector] YOLOv8 Normal Vehicle Counting Paused.")

    def restart_detection(self):
        """Restarts YOLOv8 vehicle detection and lane-wise vehicle counting."""
        self.ai_detection_active = True
        print("[Detector] ✅ YOLOv8 Vehicle Detection & Lane-wise Counting Restarted.")

    def process_frame_simulation(self, lane_vehicles_data: List[Dict]) -> Tuple[Dict[int, int], List[DetectedObject], List[DetectedObject]]:
        """
        Processes simulated camera feed / vehicle state.
        Returns:
            - lane_counts: Dict[lane_id, count]
            - all_detections: List[DetectedObject]
            - emergency_detections: List[DetectedObject]
        """
        lane_counts = {1: 0, 2: 0, 3: 0, 4: 0}
        all_detections: List[DetectedObject] = []
        emergency_detections: List[DetectedObject] = []

        if not self.ai_detection_active:
            return self.last_detection_summary, [], []

        for item in lane_vehicles_data:
            lane = item.get("lane_id", 1)
            v_type = item.get("type", "car").lower()
            v_id = item.get("id", "v_0")
            bbox = item.get("bbox", (0.0, 0.0, 50.0, 50.0))
            conf = item.get("confidence", round(random.uniform(0.85, 0.98), 2))

            is_emergency = v_type in self.EMERGENCY_CLASSES or item.get("is_emergency", False)

            obj = DetectedObject(
                object_id=v_id,
                class_name=v_type,
                confidence=conf,
                lane_id=lane,
                bbox=bbox,
                is_emergency=is_emergency
            )

            all_detections.append(obj)

            if is_emergency:
                emergency_detections.append(obj)
            else:
                lane_counts[lane] += 1

        self.last_detection_summary = lane_counts
        return lane_counts, all_detections, emergency_detections

    def get_detector_status(self) -> Dict[str, any]:
        """Returns current status of YOLOv8 detection engine."""
        return {
            "ai_detection_status": "ACTIVE" if self.ai_detection_active else "PAUSED",
            "confidence_threshold": self.confidence_threshold,
            "lane_vehicle_counts": self.last_detection_summary
        }
`
  },
  {
    filename: 'simulation.py',
    description: 'Intersection Physics Simulation. Orchestrates 4-lane vehicle movement, bounding box updates, traffic lights, and spatial clearance trigger.',
    code: `"""
simulation.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Intersection Simulator Engine
===============================================================================

This module provides:
1. Physics & spatial tracking model for 4-lane traffic intersection.
2. Animated vehicle motion, stopping at RED signals, accelerating on GREEN.
3. Emergency vehicle entry, approach, crossing, and automatic exit boundary check.
4. Integrated pipeline combining Detector, Signal Controller, and Emergency Manager.
"""

from typing import List, Dict, Tuple, Optional
import random
import time

from emergency import EmergencyManager, EmergencyVehicle
from traffic_controller import TrafficSignalController, SignalState
from detector import YOLOv8VehicleDetector, DetectedObject


class SimulatedVehicle:
    """Represents a simulated vehicle moving through the intersection."""

    def __init__(self, veh_id: str, veh_type: str, lane_id: int, is_emergency: bool = False):
        self.veh_id = veh_id
        self.veh_type = veh_type
        self.lane_id = lane_id    # 1: North, 2: South, 3: East, 4: West
        self.is_emergency = is_emergency

        self.width = 40.0 if not is_emergency else 48.0
        self.height = 24.0 if not is_emergency else 28.0

        if lane_id == 1:  # North (moving South)
            self.x = 360.0
            self.y = 20.0
            self.vx, self.vy = 0.0, 120.0
        elif lane_id == 2:  # South (moving North)
            self.x = 420.0
            self.y = 760.0
            self.vx, self.vy = 0.0, -120.0
        elif lane_id == 3:  # East (moving West)
            self.x = 760.0
            self.y = 360.0
            self.vx, self.vy = -120.0, 0.0
        else:  # Lane 4: West (moving East)
            self.x = 20.0
            self.y = 420.0
            self.vx, self.vy = 120.0, 0.0

        if is_emergency:
            self.vx *= 1.4
            self.vy *= 1.4

        self.status = "approaching"

    def get_bbox(self) -> Tuple[float, float, float, float]:
        """Returns [x1, y1, x2, y2] bounding box."""
        hw = self.width / 2.0
        hh = self.height / 2.0
        return (self.x - hw, self.y - hh, self.x + hw, self.y + hh)

    def update_position(self, dt: float, signal_state: str, intersection_bounds: Dict[str, float]):
        """Updates vehicle position based on signal state and current location."""
        should_stop = False
        if not self.is_emergency and signal_state == SignalState.RED:
            if self.lane_id == 1 and 250 <= self.y <= 280:
                should_stop = True
            elif self.lane_id == 2 and 520 <= self.y <= 550:
                should_stop = True
            elif self.lane_id == 3 and 520 <= self.x <= 550:
                should_stop = True
            elif self.lane_id == 4 and 250 <= self.x <= 280:
                should_stop = True

        if not should_stop:
            self.x += self.vx * dt
            self.y += self.vy * dt

        in_x = intersection_bounds["x_min"] <= self.x <= intersection_bounds["x_max"]
        in_y = intersection_bounds["y_min"] <= self.y <= intersection_bounds["y_max"]

        if in_x and in_y:
            self.status = "in_intersection"
        elif self.status == "in_intersection":
            self.status = "cleared"


class IntersectionSimulation:
    """
    Main Orchestration Simulation Engine for 4-way Intersection.
    Runs physical simulation step and manages AI Detection, Emergency Override,
    Automatic Clearance Detection, and Dashboard Synchronization.
    """

    def __init__(self):
        self.intersection_bounds = {
            "x_min": 300.0,
            "x_max": 500.0,
            "y_min": 300.0,
            "y_max": 500.0
        }

        self.vehicles: List[SimulatedVehicle] = []
        self.detector = YOLOv8VehicleDetector()
        self.signal_controller = TrafficSignalController()
        self.emergency_manager = EmergencyManager(self.intersection_bounds)

        self.simulation_time: float = 0.0
        self.auto_spawn_traffic: bool = True
        self.vehicle_counter: int = 0

    def spawn_regular_vehicle(self, lane_id: Optional[int] = None):
        """Spawns a standard regular vehicle in target lane."""
        self.vehicle_counter += 1
        lane = lane_id or random.choice([1, 2, 3, 4])
        v_type = random.choice(["car", "car", "car", "bus", "truck", "motorcycle"])
        v = SimulatedVehicle(f"v_{self.vehicle_counter}", v_type, lane, is_emergency=False)
        self.vehicles.append(v)
        return v

    def spawn_emergency_vehicle(self, vehicle_type: str, lane_id: int) -> EmergencyVehicle:
        """
        Spawns an Emergency Vehicle in specified lane.
        Registers vehicle with EmergencyManager to trigger override or queueing.
        """
        self.vehicle_counter += 1
        v_id = f"EV_{vehicle_type.upper()[:3]}_{self.vehicle_counter}"
        sim_v = SimulatedVehicle(v_id, vehicle_type.lower(), lane_id, is_emergency=True)
        self.vehicles.append(sim_v)

        ev = EmergencyVehicle(
            vehicle_id=v_id,
            vehicle_type=vehicle_type,
            lane_id=lane_id,
            bbox=sim_v.get_bbox(),
            confidence=0.96,
            position=(sim_v.x, sim_v.y),
            speed=160.0,
            status="approaching"
        )

        reg_result = self.emergency_manager.register_emergency_vehicle(ev)

        if self.emergency_manager.override_active:
            self.signal_controller.set_emergency_override(self.emergency_manager.active_lane)

        return ev

    def step(self, dt: float = 0.1) -> Dict[str, any]:
        """
        Advances the simulation by dt seconds.
        Handles vehicle physics, detection, tracking, clearance events, and signal updates.
        """
        self.simulation_time += dt
        active_sim_vehicles = []
        detector_input = []

        for v in self.vehicles:
            sig_state = self.signal_controller.lane_signals.get(v.lane_id, SignalState.RED)
            v.update_position(dt, sig_state, self.intersection_bounds)

            if -100 <= v.x <= 900 and -100 <= v.y <= 900:
                active_sim_vehicles.append(v)
                detector_input.append({
                    "id": v.veh_id,
                    "type": v.veh_type,
                    "lane_id": v.lane_id,
                    "bbox": v.get_bbox(),
                    "is_emergency": v.is_emergency
                })

        self.vehicles = active_sim_vehicles

        # 2. YOLOv8 Vehicle Detection
        lane_counts, detections, emergency_objs = self.detector.process_frame_simulation(detector_input)

        # 3. Track Active Emergency Vehicle Position & Bounding Box Clearance
        clearance_event = None
        if self.emergency_manager.active_emergency:
            active_ev_id = self.emergency_manager.active_emergency.vehicle_id
            matched_sim = next((v for v in self.vehicles if v.veh_id == active_ev_id), None)
            if matched_sim:
                track_res = self.emergency_manager.update_vehicle_position(
                    vehicle_id=active_ev_id,
                    new_bbox=matched_sim.get_bbox(),
                    current_lane=matched_sim.lane_id
                )

                if track_res.get("status") in ["ALL_EMERGENCIES_CLEARED", "NEXT_EMERGENCY_ACTIVATED"]:
                    clearance_event = track_res
                    if track_res["status"] == "ALL_EMERGENCIES_CLEARED":
                        self.signal_controller.resume_ai_dynamic_control(lane_counts)
                        self.detector.restart_detection()
                    elif track_res["status"] == "NEXT_EMERGENCY_ACTIVATED":
                        next_lane = track_res["lane_id"]
                        self.signal_controller.set_emergency_override(next_lane)

        # 4. Update Signal Cycle
        self.signal_controller.update_cycle(dt, lane_counts)

        return {
            "time": round(self.simulation_time, 1),
            "lane_counts": lane_counts,
            "signals": self.signal_controller.get_signal_status(),
            "emergency_dashboard": self.emergency_manager.get_dashboard_state(),
            "detector_status": self.detector.get_detector_status(),
            "clearance_event": clearance_event
        }
`
  },
  {
    filename: 'dashboard.py',
    description: 'Dashboard View & Metrics Formatter. Prepares exact required dashboard statuses (INACTIVE, ACTIVE, AI Dynamic Control) and notification toast.',
    code: `"""
dashboard.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Dashboard View & Status Controller
===============================================================================

This module handles:
1. Formatting and rendering current dashboard system metrics.
2. Rendering required status fields:
   - Emergency Status: ACTIVE / INACTIVE
   - AI Detection: ACTIVE / PAUSED
   - Signal Mode: AI Dynamic Control / Emergency Override
3. Displaying active notification toasts ("✅ Emergency Cleared – AI Traffic Control Resumed").
4. Visualizing active emergency tracking coordinates and queued emergency vehicles.
"""

from typing import Dict, List, Optional
import time


class TrafficDashboard:
    """
    Dashboard Controller for AI Smart Traffic Signal System.
    Provides structured status data and formatted UI output.
    """

    def __init__(self):
        self.banner_notification: Optional[str] = None
        self.notification_history: List[str] = []

    def set_clearance_notification(self):
        """Sets required banner notification: '✅ Emergency Cleared – AI Traffic Control Resumed'"""
        msg = "✅ Emergency Cleared – AI Traffic Control Resumed"
        self.banner_notification = msg
        self.notification_history.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
        return msg

    def generate_dashboard_view(self, sim_data: Dict[str, any]) -> Dict[str, any]:
        """Generates full formatted snapshot for the UI Dashboard."""
        signals = sim_data.get("signals", {})
        emergency = sim_data.get("emergency_dashboard", {})
        lane_counts = sim_data.get("lane_counts", {1: 0, 2: 0, 3: 0, 4: 0})

        is_override = emergency.get("emergency_status") == "ACTIVE"

        return {
            "emergency_status": "ACTIVE" if is_override else "INACTIVE",
            "ai_detection": "PAUSED" if is_override else "ACTIVE",
            "signal_mode": "Emergency Override" if is_override else "AI Dynamic Control",
            "banner_notification": self.banner_notification,
            "lane_summary": {
                "Lane 1 (North)": {"count": lane_counts.get(1, 0), "signal": signals.get("lane_signals", {}).get(1, "RED")},
                "Lane 2 (South)": {"count": lane_counts.get(2, 0), "signal": signals.get("lane_signals", {}).get(2, "RED")},
                "Lane 3 (East)": {"count": lane_counts.get(3, 0), "signal": signals.get("lane_signals", {}).get(3, "RED")},
                "Lane 4 (West)": {"count": lane_counts.get(4, 0), "signal": signals.get("lane_signals", {}).get(4, "RED")},
            },
            "active_green_lane": signals.get("current_green_lane"),
            "green_timer_remaining": signals.get("timer_remaining"),
            "active_emergency": emergency.get("active_emergency_vehicle"),
            "queue_length": emergency.get("queued_count", 0),
            "queued_vehicles": emergency.get("queue_summary", [])
        }
`
  },
  {
    filename: 'main.py',
    description: 'Main Execution Demonstrator. Runs automated test cases proving queueing, bounding box tracking, clearance notification, and mode restoration.',
    code: `"""
main.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Main Executable Entry Point
===============================================================================

Executes a complete automated demonstration lifecycle:
1. Normal AI Dynamic Control & YOLOv8 Vehicle Density Counting.
2. Emergency Vehicle Detection & Instant Emergency Override Activation.
3. Multiple Emergency Vehicle Queueing (Ambulance + Fire Truck).
4. Spatial Bounding Box Position Tracking & Automatic Intersection Clearance.
5. Automated Clearance Notification ("✅ Emergency Cleared – AI Traffic Control Resumed").
6. Restoration of Dashboard Status (INACTIVE, ACTIVE, AI Dynamic Control).
7. Fully automatic transition back to AI Dynamic Timing without user intervention.
"""

from simulation import IntersectionSimulation
from dashboard import TrafficDashboard


def run_system_demo():
    print("\\n" + "="*80)
    print("   🚦 STARTING AI-BASED SMART TRAFFIC SIGNAL SYSTEM DEMONSTRATION")
    print("="*80 + "\\n")

    sim = IntersectionSimulation()
    dashboard = TrafficDashboard()

    # Step 1: Normal traffic
    for lane in [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4]:
        sim.spawn_regular_vehicle(lane_id=lane)

    # Step 2: Emergency 1 (Ambulance in Lane 1)
    sim.spawn_emergency_vehicle("Ambulance", lane_id=1)

    # Step 3: Emergency 2 while Emergency 1 active (Fire Truck in Lane 3) -> Queueing!
    sim.spawn_emergency_vehicle("Fire Truck", lane_id=3)

    # Step 4: Advance simulation until all emergencies clear automatically
    for _ in range(20):
        step_data = sim.step(dt=1.0)
        if step_data.get("clearance_event") and step_data["clearance_event"]["status"] == "ALL_EMERGENCIES_CLEARED":
            dashboard.set_clearance_notification()
            print("✅ Emergency Cleared – AI Traffic Control Resumed")
            break

    status = dashboard.generate_dashboard_view(step_data)
    print(f"Emergency Status: {status['emergency_status']}")
    print(f"AI Detection:     {status['ai_detection']}")
    print(f"Signal Mode:      {status['signal_mode']}")


if __name__ == "__main__":
    run_system_demo()
`
  }
];
