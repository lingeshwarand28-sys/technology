"""
detector.py
===============================================================================
AI-Based Smart Traffic Signal Control System - YOLOv8 Vehicle Detector Module
===============================================================================

This module handles:
1. YOLOv8 object detection simulation for multi-lane vehicle recognition.
2. Recognition of regular traffic (Cars, Buses, Trucks, Motorcycles).
3. Instant detection and bounding box tagging for Emergency Vehicles (Ambulance, Fire Truck, Police).
4. Lane-wise vehicle density counting.
5. Pause / Restart controls for YOLOv8 vehicle detection state.
"""

from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import random


@dataclass
class DetectedObject:
    """Dataclass for YOLOv8 detected vehicle object."""
    object_id: str
    class_name: str     # 'car', 'bus', 'truck', 'motorcycle', 'ambulance', 'fire_truck', 'police'
    confidence: float   # 0.0 - 1.0
    lane_id: int        # 1: North, 2: South, 3: East, 4: West
    bbox: Tuple[float, float, float, float]  # [x1, y1, x2, y2]
    is_emergency: bool


class YOLOv8VehicleDetector:
    """
    YOLOv8 Object Detection Engine for Real-Time Traffic Analysis.
    Performs lane-wise vehicle counting and scans for emergency vehicle classes.
    """

    EMERGENCY_CLASSES = ["ambulance", "fire_truck", "police", "police_vehicle"]

    def __init__(self, confidence_threshold: float = 0.5):
        self.confidence_threshold = confidence_threshold
        self.ai_detection_active: bool = True
        self.last_detection_summary: Dict[int, int] = {1: 0, 2: 0, 3: 0, 4: 0}

    def pause_detection(self):
        """Pauses normal vehicle counting (e.g. during emergency override mode if bypassed)."""
        self.ai_detection_active = False
        print("[Detector] YOLOv8 Normal Vehicle Counting Paused.")

    def restart_detection(self):
        """Restarts YOLOv8 vehicle detection and lane-wise vehicle counting."""
        self.ai_detection_active = True
        print("[Detector] ✅ YOLOv8 Vehicle Detection & Lane-wise Counting Restarted.")

    def process_frame_simulation(self, lane_vehicles_data: List[Dict]) -> Tuple[Dict[int, int], List[DetectedObject], List[DetectedObject]]:
        """
        Processes simulated camera feed / vehicle state.
        Returns:
            - lane_counts: Dict[lane_id, count]
            - all_detections: List[DetectedObject]
            - emergency_detections: List[DetectedObject]
        """
        lane_counts = {1: 0, 2: 0, 3: 0, 4: 0}
        all_detections: List[DetectedObject] = []
        emergency_detections: List[DetectedObject] = []

        if not self.ai_detection_active:
            # When paused, returns empty counts or last cached status
            return self.last_detection_summary, [], []

        for item in lane_vehicles_data:
            lane = item.get("lane_id", 1)
            v_type = item.get("type", "car").lower()
            v_id = item.get("id", "v_0")
            bbox = item.get("bbox", (0.0, 0.0, 50.0, 50.0))
            conf = item.get("confidence", round(random.uniform(0.85, 0.98), 2))

            is_emergency = v_type in self.EMERGENCY_CLASSES or item.get("is_emergency", False)

            obj = DetectedObject(
                object_id=v_id,
                class_name=v_type,
                confidence=conf,
                lane_id=lane,
                bbox=bbox,
                is_emergency=is_emergency
            )

            all_detections.append(obj)

            if is_emergency:
                emergency_detections.append(obj)
            else:
                lane_counts[lane] += 1

        self.last_detection_summary = lane_counts
        return lane_counts, all_detections, emergency_detections

    def get_detector_status(self) -> Dict[str, any]:
        """Returns current status of YOLOv8 detection engine."""
        return {
            "ai_detection_status": "ACTIVE" if self.ai_detection_active else "PAUSED",
            "confidence_threshold": self.confidence_threshold,
            "lane_vehicle_counts": self.last_detection_summary
        }
