"""
simulation.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Intersection Simulator Engine
===============================================================================

This module provides:
1. Physics & spatial tracking model for 4-lane traffic intersection.
2. Animated vehicle motion, stopping at RED signals, accelerating on GREEN.
3. Emergency vehicle entry, approach, crossing, and automatic exit boundary check.
4. Integrated pipeline combining Detector, Signal Controller, and Emergency Manager.
"""

from typing import List, Dict, Tuple, Optional
import random
import math
import time

from emergency import EmergencyManager, EmergencyVehicle
from traffic_controller import TrafficSignalController, SignalState
from detector import YOLOv8VehicleDetector, DetectedObject


class SimulatedVehicle:
    """Represents a simulated vehicle moving through the intersection."""

    def __init__(self, veh_id: str, veh_type: str, lane_id: int, is_emergency: bool = False):
        self.veh_id = veh_id
        self.veh_type = veh_type  # 'car', 'bus', 'truck', 'ambulance', 'fire_truck', 'police'
        self.lane_id = lane_id    # 1: North (moving down), 2: South (moving up), 3: East (moving left), 4: West (moving right)
        self.is_emergency = is_emergency

        # Standard lane starting coordinates [x, y]
        # Intersection canvas: 800 x 800. Center box: [300, 500, 300, 500]
        self.width = 40.0 if not is_emergency else 48.0
        self.height = 24.0 if not is_emergency else 28.0

        if lane_id == 1:  # North (moving South)
            self.x = 360.0
            self.y = 20.0
            self.vx, self.vy = 0.0, 120.0  # px/sec
        elif lane_id == 2:  # South (moving North)
            self.x = 420.0
            self.y = 760.0
            self.vx, self.vy = 0.0, -120.0
        elif lane_id == 3:  # East (moving West)
            self.x = 760.0
            self.y = 360.0
            self.vx, self.vy = -120.0, 0.0
        else:  # Lane 4: West (moving East)
            self.x = 20.0
            self.y = 420.0
            self.vx, self.vy = 120.0, 0.0

        if is_emergency:
            # Emergency vehicles move faster
            self.vx *= 1.4
            self.vy *= 1.4

        self.status = "approaching"  # 'approaching', 'in_intersection', 'cleared'

    def get_bbox(self) -> Tuple[float, float, float, float]:
        """Returns [x1, y1, x2, y2] bounding box."""
        hw = self.width / 2.0
        hh = self.height / 2.0
        return (self.x - hw, self.y - hh, self.x + hw, self.y + hh)

    def update_position(self, dt: float, signal_state: str, intersection_bounds: Dict[str, float]):
        """Updates vehicle position based on signal state and current location."""
        # Stop lines
        # Lane 1 (North): stop line at y = 280
        # Lane 2 (South): stop line at y = 520
        # Lane 3 (East): stop line at x = 520
        # Lane 4 (West): stop line at x = 280

        should_stop = False
        if not self.is_emergency and signal_state == SignalState.RED:
            if self.lane_id == 1 and 250 <= self.y <= 280:
                should_stop = True
            elif self.lane_id == 2 and 520 <= self.y <= 550:
                should_stop = True
            elif self.lane_id == 3 and 520 <= self.x <= 550:
                should_stop = True
            elif self.lane_id == 4 and 250 <= self.x <= 280:
                should_stop = True

        if not should_stop:
            self.x += self.vx * dt
            self.y += self.vy * dt

        # Update status
        in_x = intersection_bounds["x_min"] <= self.x <= intersection_bounds["x_max"]
        in_y = intersection_bounds["y_min"] <= self.y <= intersection_bounds["y_max"]

        if in_x and in_y:
            self.status = "in_intersection"
        elif self.status == "in_intersection":
            # If it was in intersection and now outside, it has cleared!
            self.status = "cleared"


class IntersectionSimulation:
    """
    Main Orchestration Simulation Engine for 4-way Intersection.
    Runs physical simulation step and manages AI Detection, Emergency Override,
    Automatic Clearance Detection, and Dashboard Synchronization.
    """

    def __init__(self):
        self.intersection_bounds = {
            "x_min": 300.0,
            "x_max": 500.0,
            "y_min": 300.0,
            "y_max": 500.0
        }

        self.vehicles: List[SimulatedVehicle] = []
        self.detector = YOLOv8VehicleDetector()
        self.signal_controller = TrafficSignalController()
        self.emergency_manager = EmergencyManager(self.intersection_bounds)

        self.simulation_time: float = 0.0
        self.auto_spawn_traffic: bool = True
        self.vehicle_counter: int = 0

    def spawn_regular_vehicle(self, lane_id: Optional[int] = None):
        """Spawns a standard regular vehicle in target lane."""
        self.vehicle_counter += 1
        lane = lane_id or random.choice([1, 2, 3, 4])
        v_type = random.choice(["car", "car", "car", "bus", "truck", "motorcycle"])
        v = SimulatedVehicle(f"v_{self.vehicle_counter}", v_type, lane, is_emergency=False)
        self.vehicles.append(v)
        return v

    def spawn_emergency_vehicle(self, vehicle_type: str, lane_id: int) -> EmergencyVehicle:
        """
        Spawns an Emergency Vehicle (Ambulance, Fire Truck, Police Vehicle) in specified lane.
        Registers vehicle with EmergencyManager to trigger override or queueing.
        """
        self.vehicle_counter += 1
        v_id = f"EV_{vehicle_type.upper()[:3]}_{self.vehicle_counter}"
        sim_v = SimulatedVehicle(v_id, vehicle_type.lower(), lane_id, is_emergency=True)
        self.vehicles.append(sim_v)

        ev = EmergencyVehicle(
            vehicle_id=v_id,
            vehicle_type=vehicle_type,
            lane_id=lane_id,
            bbox=sim_v.get_bbox(),
            confidence=0.96,
            position=(sim_v.x, sim_v.y),
            speed=160.0,
            status="approaching"
        )

        reg_result = self.emergency_manager.register_emergency_vehicle(ev)

        # If override was activated immediately, set signals to lock
        if self.emergency_manager.override_active:
            self.signal_controller.set_emergency_override(self.emergency_manager.active_lane)

        return ev

    def step(self, dt: float = 0.1) -> Dict[str, any]:
        """
        Advances the simulation by dt seconds.
        Handles:
        1. Vehicle physics & positioning
        2. YOLOv8 vehicle detection & lane counting
        3. Emergency vehicle location tracking & automatic clearance check
        4. Traffic light signal controller updates
        5. State transitions (Emergency -> AI Dynamic Control)
        """
        self.simulation_time += dt

        # 1. Update vehicle positions
        active_sim_vehicles = []
        detector_input = []

        for v in self.vehicles:
            sig_state = self.signal_controller.lane_signals.get(v.lane_id, SignalState.RED)
            v.update_position(dt, sig_state, self.intersection_bounds)

            # Keep vehicles that are within canvas bounds (0 to 800)
            if -100 <= v.x <= 900 and -100 <= v.y <= 900:
                active_sim_vehicles.append(v)
                detector_input.append({
                    "id": v.veh_id,
                    "type": v.veh_type,
                    "lane_id": v.lane_id,
                    "bbox": v.get_bbox(),
                    "is_emergency": v.is_emergency
                })

        self.vehicles = active_sim_vehicles

        # 2. YOLOv8 Vehicle Detection
        lane_counts, detections, emergency_objs = self.detector.process_frame_simulation(detector_input)

        # Scan for newly detected emergency vehicles from detector
        for ev_obj in emergency_objs:
            if not any(ev.vehicle_id == ev_obj.object_id for ev in [self.emergency_manager.active_emergency] + self.emergency_manager.emergency_queue if ev):
                # Auto-register detected emergency vehicle
                ev_type_formatted = "Ambulance" if "amb" in ev_obj.class_name else ("Fire Truck" if "fire" in ev_obj.class_name else "Police Vehicle")
                ev = EmergencyVehicle(
                    vehicle_id=ev_obj.object_id,
                    vehicle_type=ev_type_formatted,
                    lane_id=ev_obj.lane_id,
                    bbox=ev_obj.bbox,
                    confidence=ev_obj.confidence,
                    position=((ev_obj.bbox[0] + ev_obj.bbox[2])/2, (ev_obj.bbox[1] + ev_obj.bbox[3])/2)
                )
                self.emergency_manager.register_emergency_vehicle(ev)
                if self.emergency_manager.override_active and self.signal_controller.signal_mode != "Emergency Override":
                    self.signal_controller.set_emergency_override(self.emergency_manager.active_lane)

        # 3. Track Active Emergency Vehicle Position & Bounding Box Clearance
        clearance_event = None
        if self.emergency_manager.active_emergency:
            active_ev_id = self.emergency_manager.active_emergency.vehicle_id
            # Find matching simulated vehicle
            matched_sim = next((v for v in self.vehicles if v.veh_id == active_ev_id), None)
            if matched_sim:
                track_res = self.emergency_manager.update_vehicle_position(
                    vehicle_id=active_ev_id,
                    new_bbox=matched_sim.get_bbox(),
                    current_lane=matched_sim.lane_id
                )

                if track_res.get("status") in ["ALL_EMERGENCIES_CLEARED", "NEXT_EMERGENCY_ACTIVATED"]:
                    clearance_event = track_res
                    if track_res["status"] == "ALL_EMERGENCIES_CLEARED":
                        # Fully automatic transition back to AI Dynamic Control (Requirement #6, #11)
                        self.signal_controller.resume_ai_dynamic_control(lane_counts)
                        self.detector.restart_detection()
                    elif track_res["status"] == "NEXT_EMERGENCY_ACTIVATED":
                        # Lock signals for next queued emergency vehicle (Requirement #9)
                        next_lane = track_res["lane_id"]
                        self.signal_controller.set_emergency_override(next_lane)

        # 4. Update Signal Cycle
        self.signal_controller.update_cycle(dt, lane_counts)

        # Return snapshot
        return {
            "time": round(self.simulation_time, 1),
            "lane_counts": lane_counts,
            "signals": self.signal_controller.get_signal_status(),
            "emergency_dashboard": self.emergency_manager.get_dashboard_state(),
            "detector_status": self.detector.get_detector_status(),
            "clearance_event": clearance_event,
            "vehicle_positions": [
                {
                    "id": v.veh_id,
                    "type": v.veh_type,
                    "lane": v.lane_id,
                    "x": round(v.x, 1),
                    "y": round(v.y, 1),
                    "is_emergency": v.is_emergency,
                    "status": v.status
                } for v in self.vehicles
            ]
        }
