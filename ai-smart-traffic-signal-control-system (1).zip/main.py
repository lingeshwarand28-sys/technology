"""
main.py
===============================================================================
AI-Based Smart Traffic Signal Control System - Main Executable Entry Point
===============================================================================

Executes a complete automated demonstration lifecycle:
1. Normal AI Dynamic Control & YOLOv8 Vehicle Density Counting.
2. Emergency Vehicle Detection & Instant Emergency Override Activation.
3. Multiple Emergency Vehicle Queueing (Ambulance + Fire Truck).
4. Spatial Bounding Box Position Tracking & Automatic Intersection Clearance.
5. Automated Clearance Notification ("✅ Emergency Cleared – AI Traffic Control Resumed").
6. Restoration of Dashboard Status (INACTIVE, ACTIVE, AI Dynamic Control).
7. Fully automatic transition back to AI Dynamic Timing without user intervention.
"""

import time
from simulation import IntersectionSimulation
from dashboard import TrafficDashboard


def run_system_demo():
    print("\n" + "="*80)
    print("   🚦 STARTING AI-BASED SMART TRAFFIC SIGNAL SYSTEM DEMONSTRATION")
    print("="*80 + "\n")

    # Initialize Simulation Engine and Dashboard
    sim = IntersectionSimulation()
    dashboard = TrafficDashboard()

    # Step 1: Populate normal traffic flow across lanes
    print("[1] Spawning regular vehicles across 4 lanes...")
    for lane in [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4]:
        sim.spawn_regular_vehicle(lane_id=lane)

    # Step 2: Step simulation under AI Dynamic Control
    print("\n--- PHASE 1: Normal AI Dynamic Signal Control ---")
    step_data = sim.step(dt=1.0)
    status = dashboard.generate_dashboard_view(step_data)
    dashboard.render_cli_dashboard(status)

    # Step 3: Emergency Vehicle 1 Detected (Ambulance in Lane 1)
    print("\n--- PHASE 2: Emergency Vehicle 1 Detected (Ambulance in Lane 1) ---")
    ambulance = sim.spawn_emergency_vehicle("Ambulance", lane_id=1)
    
    step_data = sim.step(dt=1.0)
    status = dashboard.generate_dashboard_view(step_data)
    dashboard.render_cli_dashboard(status)

    # Step 4: Emergency Vehicle 2 Detected while EV 1 is active (Fire Truck in Lane 3) -> QUEUEING (Requirement #9)
    print("\n--- PHASE 3: Second Emergency Vehicle Detected (Fire Truck in Lane 3) -> Queueing ---")
    fire_truck = sim.spawn_emergency_vehicle("Fire Truck", lane_id=3)

    step_data = sim.step(dt=1.0)
    status = dashboard.generate_dashboard_view(step_data)
    dashboard.render_cli_dashboard(status)

    # Step 5: Advance Ambulance through intersection until clearance
    print("\n--- PHASE 4: Tracking Ambulance crossing intersection... ---")
    for step_num in range(1, 6):
        step_data = sim.step(dt=1.5)
        if step_data.get("clearance_event"):
            print(f"   ⚡ Clearance Event Fired: {step_data['clearance_event']['message']}")
            break

    status = dashboard.generate_dashboard_view(step_data)
    dashboard.render_cli_dashboard(status)

    # Step 6: Advance Fire Truck through intersection until final clearance
    print("\n--- PHASE 5: Tracking Queued Fire Truck crossing intersection... ---")
    for step_num in range(1, 6):
        step_data = sim.step(dt=1.5)
        if step_data.get("clearance_event"):
            event = step_data["clearance_event"]
            if event.get("status") == "ALL_EMERGENCIES_CLEARED":
                dashboard.set_clearance_notification()
                print(f"\n🎉 {dashboard.banner_notification}\n")
                break

    # Step 7: Final Dashboard State Verification
    print("\n--- PHASE 6: Fully Automatic Transition Back to AI Dynamic Control ---")
    step_data = sim.step(dt=1.0)
    final_status = dashboard.generate_dashboard_view(step_data)
    dashboard.render_cli_dashboard(final_status)

    # Verify Requirements
    print("="*80)
    print(" VERIFICATION CHECKLIST:")
    print(f"  [✓] Notification Banner : {final_status['banner_notification']}")
    print(f"  [✓] Emergency Status    : {final_status['emergency_status']} (Expected: INACTIVE)")
    print(f"  [✓] AI Detection        : {final_status['ai_detection']} (Expected: ACTIVE)")
    print(f"  [✓] Signal Mode         : {final_status['signal_mode']} (Expected: AI Dynamic Control)")
    print(f"  [✓] Queued Count        : {final_status['queue_length']} (Expected: 0)")
    print("="*80 + "\n")


if __name__ == "__main__":
    run_system_demo()
